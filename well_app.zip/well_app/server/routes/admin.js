var express = require('express');
var router = express.Router();
var mutipart= require('connect-multiparty');
var mutipartMiddeware = mutipart({
    uploadDir: './public/tmp'
});

var adminDao = require('../dao/adminDao');
/* GET users listing. */
router.post('/admin/app/login', function (req, res, next) {
    adminDao.login(req, res, next);
});

router.post('/admin/app/loginOut', function (req, res, next) {
    adminDao.loginOut(req, res, next);
});

router.post('/admin/app/userList', function (req, res, next) {
    adminDao.queryUserAll(req, res, next);
});

router.post('/admin/app/updatePassword', function (req, res, next) {
    adminDao.updatePassword(req, res, next);
});

router.post('/admin/app/bannerList', function (req, res, next) {
    adminDao.queryBannerAll(req, res, next);
});

router.post('/admin/app/addBanner', function (req, res, next) {
    adminDao.addBanner(req, res, next);
});

router.post('/admin/app/deleteBanner', function (req, res, next) {
    adminDao.deleteBanner(req, res, next);
});

router.post('/admin/app/setInfo', function (req, res, next) {
    adminDao.setInfo(req, res, next);
});

router.post('/admin/upload',mutipartMiddeware,function (req,res) {  
    var fileName = '';
    var code = 1;
    if (req.files && req.files.file && req.files.file.path) {
        code = 0;
        fileName = req.files.file.path.replace(/\\/g, '\/').replace('public/tmp/', '');
    };
    res.json({code: code, fileName: fileName});
});








module.exports = router;
