var express = require('express');
var router = express.Router();

var clientDao = require('../dao/clientDao');
/* GET users listing. */


router.post('/app/typeList', function (req, res, next) {
    clientDao.queryTypeList(req, res, next);
});

router.post('/app/tList', function (req, res, next) {
    clientDao.queryAll(req, res, next);
});

router.post('/app/guessList', function (req, res, next) {
    clientDao.queryGuess(req, res, next);
});

router.post('/app/login', function (req, res, next) {
    clientDao.login(req, res, next);
});

router.post('/app/loginOut', function (req, res, next) {
    clientDao.loginOut(req, res, next);
});

router.post('/app/register', function (req, res, next) {
    clientDao.register(req, res, next);
});

router.post('/app/bankList', function (req, res, next) {
    clientDao.queryBannerAll(req, res, next);
});

router.post('/app/appInfo', function (req, res, next) {
    clientDao.queryInfo(req, res, next);
});

router.post('/app/update', function (req, res, next) {
    clientDao.appUpdate(req, res, next);
});


module.exports = router;
