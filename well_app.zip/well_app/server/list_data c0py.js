var request = require("request");
var cheerio = require('cheerio');
const iconv = require('iconv-lite');
var mysql = require('mysql');
var pageNum = 0;
var dtNum = 0;
var arr = [];
// 广告联系方式：QQ:1813637039 (Skype帐号)邮箱：wangdong101028@gmail.com
// 站务联系方式：9188zy@gmail.com
// 可达鸭 http://kdy999.net/#wz9
var resour = 'http://www.69aab.com';
var items = [
    {url: '/list/?1-', type: '亚洲无码', num: 90},//90
    {url: '/list/?2-', type: '有码视频', num: 90},//90
    {url: '/list/?3-', type: '自拍偷拍', num: 90},//90
    {url: '/list/?4-', type: '欧美性爱', num: 90},//90
    {url: '/list/?5-', type: '动漫卡通', num: 39},//39
    {url: '/list/?6-', type: '三级伦理', num: 4},//4
    {url: '/list/?36-', type: '中文字幕', num: 90},//90
    {url: '/list/?42-', type: '韩国专区', num: 50},//50
    {url: '/list/?54-', type: '强奸乱伦', num: 9},//9
    {url: '/list/?55-', type: 'JAVHD高清', num: 1},//1
    {url: '/list/?49-', type: '中文动漫', num: 2}//2
]
var ip = [
    '14.192.76.22',
    '27.54.72.21',
    '27.224.0.14',
    '36.0.32.19',
    '36.37.40.21',
    '36.96.0.11',
    '39.0.0.24',
    '39.0.128.17',
    '40.0.255.24',
    '40.251.227.24',
    '42.0.8.21',
    '42.1.48.21',
    '42.1.56.22',
    '42.62.128.19',
    '42.80.0.15',
    '42.83.64.20',
    '42.96.96.21',
    '42.99.112.22',
    '42.99.120.21',
    '42.100.0.14',
    '42.157.128.20',
    '42.187.96.20',
    '42.194.64.18',
    '42.248.0.13',
    '43.224.212.22',
    '43.225.236.22',
    '43.226.32.19',
    '43.241.88.21',
    '43.242.64.22',
    '43.247.152.22',
    '45.116.208.24',
    '45.120.243.24'
];
var pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'ashun666',
    database: 'app',
    useConnectionPooling: true
});

function getAjax(url) {
    return new Promise((resolve, reject) => {
        var options = {
            method: 'GET',
            url: url,
            gzip: true,
            encoding: null,
            headers: {
                "X-Forwarded-For": ip[Math.floor(Math.random()*ip.length)] || '42.194.64.18',
                'User-Agent': 'Mozilla/8.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36',
                'referer': 'https://www.69aab.com/',
                'Cookie': "UM_distinctid=171edaa64ac60a-036b66bef6da7-30617d00-13c680-171edaa64adcfd; PHPSESSID=38okhj9d1ds7vs4ej29drbbs57; Hm_lvt_9ece29102c03c697cec3d4848b12b4ac=1600848867,1600848919,1600849020; Hm_lvt_367c73c5c8b17e98a0af3cf661b0ba67=1600848867,1600848919,1600849020; Hm_lvt_066be9e8ee7a592f80be703be870366b=1600848867,1600848919,1600849020; fikker-JJbc-6WOO=hiIwRiZ1R5hQBw4NdJr3LCI1VmTNXmZQ; fikker-JJbc-6WOO=hiIwRiZ1R5hQBw4NdJr3LCI1VmTNXmZQ; CNZZDATA1263393274=1136513544-1588828692-%7C1601183149; Hm_lpvt_9ece29102c03c697cec3d4848b12b4ac=1601187699; Hm_lpvt_066be9e8ee7a592f80be703be870366b=1601187699; Hm_lpvt_367c73c5c8b17e98a0af3cf661b0ba67=1601187699"
            }
        };
        request(options, function (error, response, body) {
            
            try {
                if (error) throw error;
                var buf = iconv.decode(body, 'UTF-8');//获取内容进行转码
                $ = cheerio.load(buf);
                
                // console.log($.html())

                resolve();
            } catch (e) {
                console.log(options.url, '获取数据失败')
                reject(e);
            }
        })
    });
}

function getList () {
    var urlC = resour + items[pageNum].url + (items[pageNum].num - dtNum) + '.html';;
    getAjax(urlC).then(function (){
        var li = $('.addition-content .videoContent li');
        var title = '';
        var url = '';
        var date = '';
        var address = '';
        var type = items[pageNum].type;
        for (var i = 0; i < li.length; i++) {
            title = $('.videoName', li[i]).text();
            url = $('.videoName', li[i]).attr('href');
            address = $('.region', li[i]).text();
            date = $('.time', li[i]).text();//.eq(0).text();
            arr.push({url:url, title: title, address: address, date: date, type: type});
        }
        dtNum++
        if ((items[pageNum].num - dtNum) > 0) {
            console.log('current page is========', dtNum);
            getList();
        } else {
            pageNum++
            if (pageNum === items.length) {
                if (arr.length) {
                    var nArr = JSON.parse(JSON.stringify(arr));
                    arr = [];
                    pageNum = 0;
                    dtNum = 0;
                    // console.log(nArr.length, '=====')
                    // return;
                    listArr(nArr);
                } else {
                    console.log('没有数据')
                }
            } else {
                dtNum = 0;
                getList();
            }
        }
    }, function () {
        getList();
    });
}

function listArr (list) {
    if (dtNum === list.length) {
        console.log('end--', dtNum, 'current-time--', new Date().getTime());
        var date = new Date();
        var timeS = new Date(date.getFullYear() +'-' + (date.getMonth()+1) + '-' + date.getDate() + ' 06:00:00').getTime();
        setTimeout(function () {
            getList();
        }, (timeS + (24 * 60 * 60 * 1000)) - date.getTime());
    } else {      
        var sql = 'select * from t_list where url ="' + list[dtNum].url +'"';
        var infoReal = "INSERT INTO t_list(title,url,img,video,cover,type,address,pay_total,get_date,create_date) VALUES (?,?,?,?,?,?,?,?,?,?)";
        pool.getConnection(function (err, conn) {
            if (err) console.log("detail ==> " + err);
            conn.query(sql, function (err2, rows, fields) {
                if (err2) {
                    console.log('[chear ERROR2] - ', err2.message);
                    conn.release();
                    listArr(list);
                } else {
                    if (rows.length) {
                        dtNum++;
                        conn.release();
                        listArr(list);
                    } else {
                        function getDetail(dUrl) {
                            getAjax(dUrl).then(function () {
                                var img = $('.people .left img').attr('src');
                                var video = $('.people .ardess .playlist li a').text();
                                var cover = $('.people').children('div:last-child').children('img').attr('src');
                                if (cover && cover.indexOf('http') <= -1) {
                                    cover = 'https://p6.jals1rfsfo.com' + cover;
                                }
                                var arr = [
                                    list[dtNum].title,
                                    list[dtNum].url,
                                    img,
                                    video,
                                    cover,
                                    list[dtNum].type,
                                    list[dtNum].address,
                                    Math.ceil(Math.random()*(900000-400000+1)+400000),
                                    list[dtNum].date,
                                    new Date()
                                ]
                                // console.log(video,'====')
                                if (video) {
                                    conn.query(infoReal, arr, function (err, rows, fields) {});
                                }
                                setTimeout(function () {
                                    console.log('current page' + dtNum,'====')
                                    conn.release();
                                    dtNum++;
                                    listArr(list);
                                }, 1000);
                            }, function () {
                                getDetail(dUrl);
                            });
                        }
                        getDetail(resour + list[dtNum].url);
                    }
                }
            });
        });
    }
}

getList();
// function deleteNot() {
//     var sql = 'SELECT list.* FROM list LEFT JOIN defDetail ON list.createTime = defDetail.createTime WHERE defDetail.createTime is null';
//     var delSql = 'DELETE list FROM list LEFT JOIN defDetail ON list.createTime = defDetail.createTime WHERE defDetail.createTime is null';
//     pool.getConnection(function (err, conn) {
//         if (err) console.log("POOL ==> " + err);
//         conn.query(sql, function (err, rows, fields) {
//             if (err) console.log('[chear ERROR] - ', err.message);
//             console.log(rows.length, '=======');
//             conn.release();
//         })
//     });
// }
// var num = 0;
// function allData() {
//     var sql = 'select * from meitu_list';
//     var updateSql = 'update meitu_detail set id = "';
//     pool.getConnection(function (err, conn) {
//         if (err) console.log("POOL ==> " + err);
//         conn.query(sql, function (err, rows, fields) {
//             if (err) console.log('[chear ERROR] - ', err.message);
//             console.log(rows.length, '=======');
//             for(var i =0; i < rows.length; i++) {
//                 conn.query(updateSql+rows[i].id+'" where url = "' + rows[i].url +'"', function (err, rows, fields) {
//                     if (err) console.log('[chear ERROR] - ', err.message);
//                     console.log(num++)
//                 })
//             }
//             conn.release();
//         })
//     });
// }
// allData()
// getList();