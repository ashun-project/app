## 介绍

nothing

**node.js 版本为：11.12.0**

**npm 版本为：6.7.0**

## 启动

``` bash
1、进入到目录底下，安装插件，例如 express_project 目录底下
$ npm install
$ npm run start
2、初始化 sql 脚本，需要进入目录 /express_project/bin/db/,执行以下脚本语句 
## 注意：执行后会重新创建，正在运行的项目不可操作
$ sh setup.sh

