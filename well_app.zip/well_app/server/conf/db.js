// conf/db.js
// MySQL数据库联接配置
module.exports = {
  mysql: {
    host: '127.0.0.1',
    user: 'root',
    password: 'ashun666',
    database: 'app',
    port: 3306
  }
};
