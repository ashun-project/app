var logger = require('../common/logger');
var fs = require('fs');
var conf = require('../conf/db');
var mysql = require('mysql');
var pool = mysql.createPool(conf.mysql);

// 向前台返回JSON方法的简单封装
var jsonWrite = function (res, err, ret) {
    // console.log(ret, '====')
    var obj = { code: 0, message: '操作成功', data: ret };
    if (err) {
        logger.error(err);
        obj.code = 1;
        obj.message = '操作失败';
    }
    res.json(obj);
};
var inviteCode = function() {
    return new Promise(function (resolve, reject){
        chaxun();
        function chaxun() {
            var arr = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z",
                    0,1,2,3,4,5,6,7,8,9];
            var rand1 = Math.floor((Math.random()*36));
            var rand2 = Math.floor((Math.random()*36));
            var rand3 = Math.floor((Math.random()*36));
            var rand4 = Math.floor((Math.random()*36));
            var rand5 = Math.floor((Math.random()*36));
            var rand6 = Math.floor((Math.random()*36));
            var result = ('' + arr[rand1] + arr[rand2] + arr[rand3] + arr[rand4] + arr[rand5] + arr[rand6]);
            // console.log(result, '=====')
            var checkIn = "SELECT * FROM t_user WHERE invitation = '" + result +"'";
            pool.getConnection(function (err, conn) {
                if (err) console.log("POOL refresh-register==> " + err);
                conn.query(checkIn, function (err, chResult) {
                    if (err) {
                        console.log(err, '创建邀请码失败')
                        conn.release();
                        reject();
                    }
                    if (chResult && !chResult.length) {
                        resolve(result);
                        conn.release();
                    } else {
                        conn.release();
                        chaxun();
                    }
                })
            })
        }
    })
};
var filterQuery = function (keys, value, limit) {
    var date = false;
    var arr = [];
    var queryResult = {where: '', limit: ''};

    for (var i = 0; i < keys.length; i++) {
        if (value[keys[i]]) {
            if (keys[i] == 'startTime' || keys[i] == 'endTime') {
                date =  true;
            } else if (keys[i] == 'downDate') {
                arr.push("down_date < '" + value[keys[i]] + "' OR down_date IS NULL");
            } else if (keys[i] == 'examineDate') {
                arr.push("examine_date > '" + value[keys[i]] + "'");
            } else if (keys[i] == 'search') {
                arr.push("title like '%" + value[keys[i]] + "%'");
            } else {
                if (typeof value[keys[i]] == 'number') {
                    arr.push(keys[i] + " = " + value[keys[i]]);
                } else {
                    arr.push(keys[i] + " = '" + value[keys[i]] + "'");
                }
            }
        }
    }
    if (date) {
        arr.push("create_date between '"+ value.startTime +"' and '"+ value.endTime +"'");
    }
    if (arr.length) {
        queryResult.where = " where " + arr.join(' and ');
    }
    if (limit) {
        var pageSize = value.pageSize || 10;
        var page = value.page || 1;
        var limitNum = (page - 1) * pageSize;
        queryResult.limit = " limit " + (limitNum + "," + pageSize)
    }
    return queryResult;
}
// 迁移临时文件
var moveFile = function (type, img, tmpType) {
    var tmp = process.cwd() + '/public/' + (tmpType || 'tmp') + '/';
    var mub = process.cwd() + '/public/' + type + '/';
    fs.exists(tmp + img, function(exists) {
        if (exists) {
            try{
                var source = fs.createReadStream(tmp + img);
                var dest = fs.createWriteStream(mub + img);
                source.pipe(dest);
                source.on('end', function() { fs.unlinkSync(tmp + img);});   //delete
            }catch (e){
                console.log('迁移文件出错')
            }
        } else {
            console.log('文件不存在1')
        }
    })
}
var deleteImg = function (path) {
    var ph = process.cwd() + '/public' + path;
    fs.exists(ph, function(exists) {
        if (exists) {
            try {
                fs.unlinkSync(ph);
            } catch (e) {
                console.log('迁移文件出错')
            }
            
        } else {
            console.log('文件不存在2')
        }
    })
    
}

module.exports = {
    jsonWrite: jsonWrite,
    inviteCode: inviteCode,
    filterQuery: filterQuery,
    moveFile: moveFile,
    deleteImg: deleteImg
}
