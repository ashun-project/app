var mysql = require('mysql');
var conf = require('../conf/db');
var logger = require('../common/logger');
// 使用连接池，提升性能
var pool = mysql.createPool(conf.mysql);
var common = require('./common');
var request = require("request");
var path = require("path");
var fs = require("fs");



module.exports = {
    login: function(req, res, next) {
        var query = req.body;
        if (query.userName == 'videoapp' && query.password == 'videoapp123456') {
            req.session.loginUser = {userName: query.userName, code: 0};
            res.json({ code: 0, message: '登录成功'})
        } else {
            res.json({ code: 1, message: '帐号密码错误'})
        }
    },
    loginOut: function(req, res, next) {
        req.session.loginUser = null;
        res.clearCookie('testapp');
        res.json({message:'退出成功', code: 0});
    },
    queryUserAll: function (req, res, next) {
        if (this.getLoginInfo(req, res)) return;
        var keys = ['id', 'account', 'invitation'];
        var query = common.filterQuery(keys, req.body, true)
        var querySql = "SELECT * FROM t_user" + query.where +" order by create_date desc" + query.limit;
        var countSql = "SELECT count(1) FROM t_user"+ query.where;
        pool.getConnection(function (err, connection) {
            if (err) logger.error(err);
            connection.query(querySql, function (err, result) {
                if (err) {
                    common.jsonWrite(res, err, result);
                    connection.release();
                } else {
                    connection.query(countSql, function (errC, count) {
                        var total = 0;
                        if (count && count[0]) total = count[0]['count(1)'];
                        common.jsonWrite(res, errC, {total: total, list: result});
                        connection.release();
                    })
                }
            });
        });
    },
    updatePassword: function(req, res, next) {
        if (this.getLoginInfo(req, res)) return;
        var query = req.body;
        var updateSql = 'update t_user set account=?, password=?, type=? where id=?';
        pool.getConnection(function (err, connection) {
            if (err) logger.error(err);
            connection.query(updateSql, [query.account, query.password, query.type, query.id], function (err, result) {
                common.jsonWrite(res, err, result);
                connection.release();
            })
        })
    },
    queryBannerAll: function (req, res, next) {
        var querySql = "SELECT * FROM t_tu";
        pool.getConnection(function (err, connection) {
            if (err) logger.error(err);
            connection.query(querySql, function (err, result) {
                common.jsonWrite(res, err, result);
                connection.release();
            });
        });
    },
    addBanner: function (req, res, next) {
        if (this.getLoginInfo(req, res)) return;
        var params = req.body;
        var addSql = 'insert into t_tu(pic, url, type, title) VALUES (?, ?, ?, ?)';
        var dataSql = [params.pic, params.url, params.type, params.title];
        pool.getConnection(function (err, connection) {
            if (err) logger.error(err);
            connection.query(addSql, dataSql, function (err, result) {
                common.moveFile('banner', params.pic);
                common.jsonWrite(res, err, result);
                connection.release();
            })
        })
    },
    deleteBanner: function (req, res, next) {
        if (this.getLoginInfo(req, res)) return;
        var query = req.body;
        var sql = "DELETE FROM t_tu WHERE id = " + query.id;
        pool.getConnection(function (err, connection) {
            if (err) logger.error(err);
            connection.query(sql, function (err, result) {
                common.deleteImg('/banner/' + query.pic);
                common.jsonWrite(res, err, result);
                connection.release();
            })
        })
    },
    setInfo: function(req, res, next) {
        if (this.getLoginInfo(req, res)) return;
        var query = req.body;
        fs.writeFileSync(process.cwd() + '/common/info.json', JSON.stringify(query), 'utf-8');
        res.json({code: 0, message: '修改成功'});
    },
    getLoginInfo(req, res) {
        if (!req.session.loginUser || req.session.loginUser.userName !== 'videoapp') {
            res.json({code: 3301, message: '请重新登录'});
            return true
        } else {
            return false
        }
    }
}