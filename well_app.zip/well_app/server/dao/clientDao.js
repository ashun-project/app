var mysql = require('mysql');
var conf = require('../conf/db');
var logger = require('../common/logger');
// 使用连接池，提升性能
var pool = mysql.createPool(conf.mysql);
var common = require('./common');
var fs = require("fs");

var typeList = [
    {type: 'mxym', category: '明星淫梦'},
    {type: 'vrym', category: 'VR有码'},
    {type: 'vrwm', category: 'VR无码', hot: 1},
    {type: 'rs', category: '人兽'},
    {type: 'ry', category: '人妖'},
    {type: 'nt', category: '男同'},
    {type: 'nt', category: '女同'},
    {type: 'yzqs', category: '亚洲情色'},
    {type: 'qjll', category: '强奸乱伦', hot: 1},
    {type: 'zptp', category: '偷拍自拍'},
    {type: 'fsgf', category: '风骚寡妇', hot: 1},
    {type: 'zfss', category: '制服师生', hot: 1},
    {type: 'omxa', category: '欧美性爱'},
    {type: 'javgq', category: 'JAV高清'},
    {type: 'dm', category: '动漫', hot: 1}
]

module.exports = {
    queryTypeList(req, res, next) {
        res.json({ code: 1, message: '密码错误', list: typeList });
    },
    queryAll: function (req, res, next) {
        var keys = ['type', 'search', 'id'];
        var orderBy = req.body.orderBy || 'get_date';
        var query = common.filterQuery(keys, req.body, true);
        var querySql = "SELECT * FROM t_list" + query.where +" order by "+ orderBy +" desc" + query.limit;
        // console.log(querySql, '===')
        pool.getConnection(function (err, connection) {
            if (err) logger.error(err);
            connection.query(querySql, function (err, result) {
                // for (var i  = 0; i < result.length; i++) {
                //     result[i].video = 'http://vod12.zjxxjt.com:8091/20200926/FqnqJtz4/index.m3u8';
                // }
                common.jsonWrite(res, err, result);
                connection.release();
            });
        });
    },
    queryGuess: function (req, res, next) {
        var countSql = "SELECT count(1) FROM t_list where type = '"+ req.body.type + "'";
        pool.getConnection(function (err, connection) {
            if (err) logger.error(err);
            connection.query(countSql, function (errC, count) {
                if (errC) {
                    common.jsonWrite(res, err, []);
                    connection.release();
                } else {
                    var pageSize = 6;
                    var total = (Number(count[0]['count(1)']) || pageSize) - pageSize;
                    var reNUm = Math.floor(Math.random()*(1 - total) + total);//10000
                    var querySql = "SELECT * FROM t_list where type = '"+ req.body.type +"' order by get_date desc limit " + (reNUm + ',' + pageSize);
                    connection.query(querySql, function (err, result) {
                        common.jsonWrite(res, err, result);
                        connection.release();
                    });
                }
            })
        });
    },
    login: function(req, res, next) {
        var query = req.body;
        var querySql = 'SELECT * FROM t_user where account=?';
        pool.getConnection(function (err, connection) {
            if (err) logger.error(err);
            connection.query(querySql, [query.account], function (err, result) {
                var obj = result ? (result[0] || {}) : {};
                if (!obj.account) {
                    res.json({ code: 1, message: '帐号不存在' });
                } else if (query.password !== obj.password) {
                    res.json({ code: 1, message: '密码错误' });
                } else {
                    req.session.loginUser = {userName: query.account, password: obj.password};
                    res.json({ code: 0, message: '登录成功', data: {userName: query.account, password: obj.password, type: obj.type, invitation: obj.invitation } });
                }
                connection.release();
            })
        })
    },
    register: function(req, res, next) {
        var vm = this;
        var query = req.body;
        var addSql = 'insert into t_user(account, password, invitation, recommend, type, create_date) VALUES (?, ?, ?, ?, ?, ?)';
        var querySql = "SELECT * FROM t_user where account = '" + query.account + "' or invitation = '" + query.recommend + "'";
        // console.log(querySql, '-----')
        if (!query.password || !query.account) {
            res.json({code: 1, message: '填写数据有误'});
            return
        }
        pool.getConnection(function (err, connection) {
            if (err) logger.error(err);
            connection.query(querySql, function(err, rows) {
                var rowsdata = rows || [];
                var isAccount = false;
                var isInvite = false;
                var id = '';
                for (var i = 0; i < rowsdata.length; i++) {
                    if (rowsdata[i].account === query.account) {
                        isAccount = true;
                    }
                    if (rowsdata[i].invitation === query.recommend) {
                        isInvite = true;
                        id = rowsdata[i].id;
                    }
                }
                if (isAccount) {
                    res.json({ code: 1, message: '帐号已存在' });
                    connection.release();
                } else if (query.recommend && !isInvite) {
                    res.json({ code: 1, message: '邀请码错误' });
                    connection.release();
                } else {
                    if (query.recommend && isInvite) {
                        vm.setRecommend(id);
                    }
                    common.inviteCode().then(invitation => {
                        connection.query(addSql, [query.account, query.password, invitation, query.recommend,0,new Date()], function (err, result) {
                            if (err) {
                                res.json({message: '注册失败', code: 1});
                            } else {
                                req.session.loginUser = {userName: query.account, password: query.password};
                                res.json({ code: 0, message: '登录成功', data: {userName: query.account, password: query.password, type: 0, invitation: invitation } });
                                connection.release();
                            }
                            
                        })
                    }).catch(function () {
                        res.json({message: '创建邀请码失败', code: 1});
                        conn.release();
                    })
                }
            })
        })
    },
    setRecommend(id) {
        var updateSql = 'update t_user set type = type + 1 where id = ' + id;
        pool.getConnection(function (err, connection) {
            if (err) logger.error(err);
            connection.query(updateSql, function (err, row) {
                connection.release();
            });
        });
    },
    loginOut: function(req, res, next) {
        req.session.loginUser = null;
        res.clearCookie('testapp');
        res.json({message:'退出成功', code: 0});
    },
    updateOrder: function (req, res, next) {
        var query = req.body;
        var updateSql = 'update t_order set status = ? where id = ?';
        pool.getConnection(function (err, connection) {
            if (err) logger.error(err);
            connection.query(updateSql, [query.status, query.id], function (err, row) {
                if (query.status == 2 && row.changedRows === 1) {
                    setRefund(query.account, query.amount, query.outorder_no);
                }
                console.log(row, query.status)
                common.jsonWrite(res, err, row);
                connection.release();
            });
        });
    },
    queryBannerAll: function (req, res, next) {
        var querySql = "SELECT * FROM t_tu";
        pool.getConnection(function (err, connection) {
            if (err) logger.error(err);
            connection.query(querySql, function (err, result) {
                common.jsonWrite(res, err, result);
                connection.release();
            });
        });
    },
    queryInfo: function (req, res, next) {  
        var examineData = fs.readFileSync(process.cwd() + '/common/info.json','utf-8');
        var examineObj = JSON.parse(examineData);
        res.json({code: 0, message: '获取成功', data: examineObj});
    },
    // 更新
    appUpdate: function (req, res, next) {
        var host = req.headers['host'];
        var obj = {
            code: 200,
            isUpdate: false,   // 整包更新
            isUpdateWgt: false,  // 资源更新
            updateApk: 'http://hgjl.me/app.apk',
            wgtUrl: 'http://hgjl.me/app.wgt',
            force: true,
            note: '重要版本更新'
        }
        if (req.body.version !== '1.0.0') {
            obj.isUpdateWgt = true;
        }
        res.json(obj);
    }
}