

var request = require("request");
var pageNum = 10;//1500;
var totalNum = 1;
// 采集总站：https://51ckx.com/index.html
// 在线地址：https://snbfpb.com/
// 狼少年采集地址 http://cjmygzy.com/inc/jsonsapi.php?ac=videolist&pg=1
// https://pyp16.com防屏蔽邮箱：lusinizy@gmail.com 
var resour = 'http://cjmygzy.com/inc/jsonsapi.php?ac=videolist&pg=';
var items = [
    {type: 'mxym', category: '明星淫梦'},
    {type: 'vrym', category: 'VR有码'},
    {type: 'vrwm', category: 'VR无码'},
    {type: 'rs', category: '人兽'},
    {type: 'ry', category: '人妖'},
    {type: 'nt', category: '男同'},
    {type: 'nt', category: '女同'},
    {type: 'yzqs', category: '亚洲情色'},
    {type: 'qjll', category: '强奸乱伦'},
    {type: 'zptp', category: '偷拍自拍'},
    {type: 'fsgf', category: '风骚寡妇'},
    {type: 'zfss', category: '制服师生'},
    {type: 'omxa', category: '欧美性爱'},
    {type: 'javgq', category: 'JAV高清'},
    {type: 'dm', category: '动漫'}
]

var mysql = require('mysql');
var conf = require('./conf/db');
var pool = mysql.createPool(conf.mysql);


function getAjax(url) {
    if (pageNum < 1) {
        console.log('get over =========')
        console.log('current-time--', new Date().getDate());
        pageNum = 10;
        var date = new Date();
        var timeS = new Date(date.getFullYear() +'-' + (date.getMonth()+1) + '-' + date.getDate() + ' 06:00:00').getTime();
        setTimeout(function () {
            getAjax();
        }, (timeS + (24 * 60 * 60 * 1000)) - date.getTime());
        return
    }
    request(resour + pageNum,function (error, response, body) {
        var data = JSON.parse(body).data;
        var bb = encodeSearchKey(JSON.stringify(data));
        var cc = decodeURIComponent(bb);
        var list = JSON.parse(cc);
        var len = list.length;
        function setInfo(num) {
            if (num < 0) {
                pageNum--
                getAjax();
                return
            }
            var sql = 'select * from t_list where vod_id ="' + list[num].vod_id + '"';
            var typeObj = items.filter(item => item.category == list[num].category)[0];
            var infoReal = "INSERT INTO t_list(title,img,video,category,type,address,pay_total,vod_id,get_date,create_date) VALUES (?,?,?,?,?,?,?,?,?,?)";
            var vdPath = list[num].vpath.replace('$ckplayer', '');
            if (vdPath && list[num].vod_pic) {
                if (vdPath.indexOf('http') > -1) {
                    var spt1 = vdPath.split('http')[1];
                    vdPath = 'http' + spt1;
                }
                pool.getConnection(function (err, conn) {
                    if (err) console.log("detail ==> " + err);
                    conn.query(sql, function (err2, rows, fields) {
                        if (!err2 && !rows.length) {
                            var arr = [
                                list[num].vod_title,
                                list[num].vod_pic,
                                vdPath,
                                list[num].category,
                                typeObj ? typeObj.type : '无',
                                list[num].vod_area,
                                Math.ceil(Math.random()*(900000-400000+1)+400000),
                                list[num].vod_id,
                                list[num].vod_addtime,
                                new Date()
                            ]
                            conn.query(infoReal, arr, function (err, rows, fields) {
                                totalNum++
                                console.log(totalNum, '====')
                                conn.release();
                                setInfo(num - 1);
                            });
                        } else {
                            conn.release();
                            setInfo(num - 1);
                        }
                    })
                })
            } else {
                setInfo(num - 1);
            }
        }
        setInfo(len-1);
    })
}

function encodeSearchKey(key) {
    const encodeArr = [{
        code: '%',
        encode: '%25'
    }, {
        code: '?',
        encode: '%3F'
    }, {
        code: '#',
        encode: '%23'
    }, {
        code: '&',
        encode: '%26'
    }, {
        code: '=',
        encode: '%3D'
    }];
    return key.replace(/[%?#&=]/g, ($, index, str) => {
        for (const k of encodeArr) {
            if (k.code === $) {
                return k.encode;
            }
        }
    });
}
getAjax()
