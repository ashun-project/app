<template>
    <div>
        <el-form :inline="true" :model="formData" class="demo-form-inline">
            <el-form-item label="帐号">
                <el-input v-model="formData.account" clearable placeholder="account"></el-input>
            </el-form-item>
            <el-form-item label="邀请码">
                <el-input v-model="formData.invitation" clearable placeholder="invitation"></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="searchList">搜索</el-button>
            </el-form-item>
        </el-form>
        <el-table :data="tableData" border style="width: 100%">
            <el-table-column prop="create_date" align="center" label="日期" width="150">
                <template slot-scope="scope">
                    <span>{{ formatDate(scope.row.create_date) }}</span>
                </template>
            </el-table-column>
            <el-table-column prop="account" align="center" label="帐号"></el-table-column>
            <el-table-column prop="password" align="center" label="密码"></el-table-column>
            <el-table-column prop="type" align="center" label="好友人数"></el-table-column>
            <el-table-column prop="invitation" align="center" label="邀请码"></el-table-column>
            <el-table-column prop="recommend" align="center" label="推荐人"></el-table-column>
            <el-table-column label="操作" align="center" width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" @click="editRow(scope.row)">修改</el-button>
                    <!-- <el-button style="color:red" @click="deleteRow(scope.row)" type="text" size="small">删除</el-button> -->
                </template>
            </el-table-column>
        </el-table>
       <div class="my-page" v-if="tableData.length">
            <el-pagination background layout="prev, pager, next" :page-size="formData.pageSize"  :total="total" @current-change="handleCurrentChange"></el-pagination>
       </div>

        <!-- 对话框 -->
        <el-dialog title="修改" :visible.sync="dialogFormVisible" class="edit">
            <el-form :model="dialogForm" label-width="120px">
                <el-form-item label="帐号">
                    <el-input v-model="dialogForm.account" autocomplete="off" style="width: 220px"></el-input>
                </el-form-item>
                <el-form-item label="秘密">
                    <el-input v-model="dialogForm.password" autocomplete="off" style="width: 220px"></el-input>
                </el-form-item>
                <el-form-item label="推荐人数">
                    <el-input v-model="dialogForm.type" autocomplete="off" style="width: 220px"></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="confirmDialog">确 定</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
export default {
    data() {
      return {
        formData: {
            invitation: '',
            account: '',
            page: 1,
            pageSize: 10
        },
        dialogFormVisible: false,
        dialogForm: {
            id: '',
            account: '',
            type: '',
            password: ''
        },
        total: 0,
        tableData: [],
        num: 0
      }
    },
    created() {
        this.getList();
    },
    methods: {
        searchList() {
            this.formData.page = 1;
            this.getList();
        },
        editRow(row) {
            // debugger
            for (var key in this.dialogForm) {
                this.dialogForm[key] = row[key]
            }
            this.dialogFormVisible = true;
        },
        deleteRow(row) {
            this.$confirm('此操作将永久删除该APP, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning',
                center: true
            }).then(() => {
                this.$http({url: '/api/admin/app/delete',  method:'post', data: {id: row.id}}).then(response => {
                    this.$Message.success('删除成功');
                    this.getList();
                })
            }).catch(() => {});
        },
        confirmDialog() {
            var obj = Object.assign({}, this.dialogForm);
            obj.type = Number(obj.type);
            this.$http({url: '/api/admin/app/updatePassword', method:'post', data: obj}).then(response => {
                this.dialogFormVisible = false;
                this.$Message.success('修改成功');
                this.getList();
            })
        },
        handleCurrentChange(page) {
            this.formData.page = page;
            this.getList();
        },
        formatDate(date) {
            return this.$common.formatDate(date);
        },
        getList() {
            this.$http({url: '/api/admin/app/userList', method:'post', data: this.formData}).then(response => {
                this.tableData = response.data.list;
                this.total = response.data.total;
            })
        }
    }
}
</script>

<style scoped>
    .demo-form-inline{
        background: #fff;
        margin: 0 -20px 20px;
        padding: 20px 20px 10px;
    }
    .el-form-item{
        margin-bottom: 10px;
    }
</style>