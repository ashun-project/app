import Vue from 'vue'
import Router from 'vue-router'
import home from '@/views/home'
import banner from '@/views/banner'
import addbanner from '@/views/addbanner'
import login from '@/views/login'
import conf from '@/views/conf'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/home',
      name: 'home',
      component: home
    },
    {
      path: '/banner',
      name: 'banner',
      component: banner
    },
    {
      path: '/addbanner',
      name: 'addbanner',
      component: addbanner
    },
    {
      path: '/',
      name: 'login',
      component: login
    },
    {
      path: '/conf',
      name: 'conf',
      component: conf
    }
  ]
})
