<script>
	export default {
		onLaunch: function() {
			console.log('App Launch');
			var vm = this;
			// #ifdef APP-PLUS
			// 锁定屏幕方向
			plus.screen.lockOrientation('portrait-primary'); //锁定
			// 检测升级
			plus.runtime.getProperty(plus.runtime.appid, function(widgetInfo) {
				uni.request({
					url: vm.$resource + '/app/update', //检查更新的服务器地址
					method: 'POST',
					data: {
						author: 'ashun',
						version: widgetInfo.version,  
						name: widgetInfo.name 
					},
					header:{
						'content-type':'application/x-www-form-urlencoded'
					},
					success: (res) => {
						if (res.data.isUpdate) {
							let openUrl = res.data.updateApk;
							if (res.data.force) { // 强制更新
								uni.showModal({
									title: '更新提示',
									showCancel: false,
									content: res.data.note ? res.data.note : '请更新应用',
									success: (showResult) => {
									  if (showResult.confirm) {
										plus.runtime.openURL(openUrl);
									  }
									}
								})
							} else { // 提醒用户更新
								uni.showModal({
									title: '更新提示',
									content: res.data.note ? res.data.note : '是否选择更新',
									success: (showResult) => {
										if (showResult.confirm) {
											plus.runtime.openURL(openUrl);
										}
									}
								})
							}
						} else if (res.data.isUpdateWgt) {
							uni.downloadFile({
								url: res.data.wgtUrl,  
								success: (downloadResult) => {
									if (downloadResult.statusCode === 200) {  
										plus.runtime.install(downloadResult.tempFilePath, {  
											force: false  
										}, function() {
											plus.runtime.restart();  
										}, function(e) {  
											console.error('install fail...');
										});  
									}  
								}
							});
						}
					}
				})
			})
			// #endif
			
			uni.request({
				url: this.$resource + '/app/typeList',
				method: 'POST',
				header:{
					'content-type':'application/x-www-form-urlencoded'
				},
				success: (res) => {
					var typeList= res.data.list || [];
					this.$store.commit('menuChange', typeList);
				}
			});
		},
		onShow: function() {
			var value = uni.getStorageSync('login-info');
			if (value) {
				uni.request({
					url: this.$resource + '/app/login',
					method: 'POST',
					data: {account: value.userName, password: value.password},
					header:{
						'content-type':'application/x-www-form-urlencoded'
					},
					success: (res) => {
						
					}
				});
			}
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style>
	/* uni.css - 通用组件、模板样式库，可以当作一套ui库应用 */
	/* @import './common/uni.css'; */

	/* 以下样式用于 hello uni-app 演示所需 */
	page {
		background-color: #111111;
		height: 100%;
		font-size: 26upx;
		line-height: 1.8;
		color: #ccc;
	}
	*{
		box-sizing: border-box;
	}
	.img {
		width: 100%;
	}
	.w-94 {
		width: 94% !important;
		margin: 0 auto;
	}
	.guanggao {
		align-items: center;
	}
	.g-list {
		display: flex;
		width: 100%;
		margin-top: 20upx;
		overflow: hidden;
		background: #fff;
		flex-wrap: wrap;
		border-radius: 18upx;
	}
	.guanggao-2 .g-list{
		border-radius: 0upx;
	}
	.guanggao .g-img {
		width: 100%;
		height: auto;
		overflow: hidden;
	}
	.guanggao img{
		width: 100%;
	}
	.t-head {
		height: 100upx;
	}
	.head-cont {
		display: flex;
		height: 100upx;
		justify-content: space-between;
		align-items: center;
		font-size: 30upx;
		position: fixed;
		top: var(--status-bar-height);
		left: 0;
		background-color: #111111;
		z-index: 10;
		width: 100%;
		padding: 0 3% 0 2%;
		border-bottom: 1px solid #232121;
		box-shadow: 0 1px 10px rgb(74 72 72 / 18%);
	}
	.t-head .head-r {
		display: flex;
		align-items: center;
	}
	.t-head .head-r .img{
		width: 20px;
	}
	.item-img{
		background: url(static/img/yjz.jpg) center no-repeat;
	    width: 100%;
		background-color: #1c1a41;
		background-size: 100%;
	}
	
	/* uni-app样式 */
	.status_bar{
		height: var(--status-bar-height);
	}
	/* #ifdef H5 */
	.status_tabar{
		height: 100upx;
	}
	/* #endif */
	.top_view {  
	    height: var(--status-bar-height);  
	    width: 100%;  
	    position: fixed;  
	    background-color: #111111;  
	    top: 0;  
	    z-index: 999;  
	}
	.uni-drawer .uni-drawer__content{
		background: linear-gradient(right , #f568ee, #b715e7);
		background: -ms-linear-gradient(right , #f568ee, #b715e7);
		background: -webkit-linear-gradient(right , #f568ee, #b715e7);
		background: -moz-linear-gradient(right , #f568ee, #b715e7);
	}
	.uni-drawer .uni-list, .uni-drawer .uni-list-item{
		background: transparent !important;
		color: #ccc;
	}
	.uni-drawer .uni-list-item__content-title{
		color: #fff !important;
	}
	.uni-drawer .uni-list-item__container:active{
		background: #f568ee !important;
	}
</style>
