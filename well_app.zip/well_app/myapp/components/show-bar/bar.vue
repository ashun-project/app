<template>
	<view class="bar-list">
		<view class="btn" @click="showMenus()">
			<uni-icons type="bars" size="26" color="#d349f7" />
		</view>
		<uni-drawer ref="drawer" mode="left">
			<scroll-view class="scroll-container" scroll-y="true">
				<view class="warp-drawer">
					<uni-list>
						<uni-list-item v-for="item in drawerMenu" :title="item.category" :clickable="true" @click="goListDetail(item.type)"></uni-list-item>
					</uni-list>
				</view>
		<!-- 	<view class="close-menu">
				<text>关闭菜单</text>
				<uni-icons type="closeempty" size="26" color="#d349f7" />
			</view> -->
			</scroll-view>
		</uni-drawer>
	</view>
</template>

<script>
	import {uniDrawer,uniList,uniListItem,uniIcons} from '@dcloudio/uni-ui'
	export default {
		data() {
			return {
				showLeft: false,
				menu: [],
				drawerMenu: []
			}
		},
		components: {uniDrawer,uniList,uniListItem,uniIcons},
		created() {
			var storeMenu = this.$store.state.menu;
			this.drawerMenu = storeMenu;
			this.menu = storeMenu.filter(item => item.show);
		},
		onBackPress() {
			if (this.showLeft) {
				this.showLeft = false
				return true
			}
		},
		methods: {
			showMenus() {
				this.$refs.drawer.open();
			},
			closeDrawer(e) {
				this.$refs.drawer.close();
			},
			goListDetail(url) {
				// debugger
				this.closeDrawer();
				this.$emit('selectMenu', url)
			},
			onClick() {
				this.$emit('click')
			}
		}
	}
</script>

<style>
	.bar-list .btn{
		text-align: right;
	}
	/* .warp-drawer {
		overflow-y: auto;
		height: 100%;
	} */
	.scroll-container {height: 100%;}
	/* .close-menu{
		color: #333;
		font-weight: 600;
		display: flex;
		justify-content: center;
		color: #fff;
	} */
</style>