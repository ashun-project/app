<template>
	<view class="start-ing" v-if="startPic">
		<image :src="$resource + '/banner/' + startPic.pic" @click="goOut(startPic.url)" @error="startLoad" @load="startLoad" style="width: 100%;height: 100%;"></image>
		<view class="close-start" @click="closeStartPic">
			<text class="second-t">{{ timesNum }}s</text>
			<text>关闭广告</text>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				startPic: '',
				timesNum: 0
			}
		},
		onLoad() {
			this.getGuangao();
		},
		methods: {
			getGuangao() {
				var vm = this;
				uni.request({
					url: this.$resource + '/app/bankList',
					method: 'POST',
					header:{
						'content-type':'application/x-www-form-urlencoded'
					},
					success: (res) => {
						var list = res.data.data || [];
						var startPic = list.filter(item => item.type == 6)[0];
						this.$store.commit('guanggaoChange', list);
						if (startPic) {
							vm.startPic = startPic;
						} else {
							vm.goHome();
						}
						
						// #ifdef APP-PLUS
						plus.navigator.closeSplashscreen();
						// #endif
					}
				});
			},
			startLoad() {
				var vm = this;
				vm.timesNum = 5;
				var timer = setInterval(function() {
					if (vm.timesNum == 0) {
						vm.goHome();
						clearInterval(timer);
					} else {
						vm.timesNum--;
					}
				}, 1000)
			},
			closeStartPic() {
				this.goHome();
			},
			goHome() {
				uni.switchTab({
				    url: '/pages/home/home'
				});
			},
			goOut(url) {
				if(!url) {
					return
				};
				// #ifdef APP-PLUS
				plus.runtime.openURL(url);
				// #endif
				// #ifndef APP-PLUS
				window.location.href = url;
				//#endif
			}
		}
	}
</script>

<style>
	.start-ing{
		height: 100%;
		position: fixed;
		bottom: 0;
		top: var(--status-bar-height);
		left: 0;
		width: 100%;
		z-index: 9999;
	}
	.start-ing .close-start {
		position: absolute;
		top: 20upx;
		right: 20upx;
		z-index: 99999;
	}
	.start-ing .second-t{
		color: #f97937;
		padding-right: 10upx;
	}
</style>
