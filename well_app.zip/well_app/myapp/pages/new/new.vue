<template>
	<view class="content">
		<!-- #ifdef APP-PLUS -->
		<view class="status_bar"><view class="top_view"></view></view>
		<!-- #endif -->

		<view class="t-head">
			<view class="head-cont">
				<view class="head-back">
					<!-- <uni-icons type="arrowleft" size="20" color="#ffffff" /> -->
				</view>
				<view class="head-title">
					最新资源
				</view>
				<view class="head-r" @click="goRoute">
					<uni-icons type="search" size="20" color="#d349f7" />
				</view>
			</view>
		</view>
		
		<view class="box-video w-94">
			<view class="box-list">
				<view class="item-list" v-for="item in dataList" :key="item.id" @click="goDetail(item)">
					<view class="item-img">
						<image class="img" :src="item.img" mode="heightFix"></image>
					</view>
					<view class="item-title">
						<text class="t-info">{{ item.title }}</text>
						<text class="t-info"><em>{{ (item.pay_total / $payCont).toFixed(2) }}</em>分<strong>·</strong><em>{{ item.pay_total }}</em>播放量</text>
					</view>
				</view>
			</view>
		</view>
		
		<uni-load-more :status="loadStatus" :contentText="contentText" @clickLoadMore="clickLoadMore"></uni-load-more>
		<!-- #ifdef H5 -->
		<view class="status_tabar"></view>  
		<!-- #endif -->
	</view>
</template>

<script>
	import {uniIcons, uniLoadMore} from '@dcloudio/uni-ui'
	export default {
		components: {uniIcons, uniLoadMore},
		data() {
			return {
				title: 'Hello',
				loadStatus: 'more',
				dataList: [],
				page: 1,
				contentText: {
					contentdown: '点击加载更多',
					contentrefresh: '正在加载...',
					contentnomore: '我是有底线的'
				}
			}
		},
		onLoad() {
			this.getList();
		},
		onPullDownRefresh() {
			this.page = 1;
			this.loadStatus = 'loading';
			this.getList(true);
		},
		onReachBottom() {
			this.getList();
		},
		methods: {
			goRoute() {
				uni.navigateTo({
					url: '/pages/search/search'
				});
			},
			clickLoadMore() {
				this.getList();
			},
			goDetail(item) {
				this.$store.commit('playDataChange', item);
				uni.navigateTo({
					url: '/pages/play/play?id=' + item.id
				});
			},
			getList(refresh) {
				if (this.loadStatus === 'noMore') {
					return;
				};
				var vm = this;
				this.loadStatus = 'loading';
				uni.request({
					url: this.$resource + '/app/tList',
					method: 'POST',
					data: {pageSize: 10, page: vm.page, orderBy: ''},
					header:{
						'content-type':'application/x-www-form-urlencoded'
					},
					success: (res) => {
						var list = res.data.data || [];
						var newList = vm.dataList.concat(list);
						vm.$set(vm, 'dataList', newList);
						vm.loadStatus = 'more';
						vm.page += 1;
						if (list.length < 10 || newList.length > 100) {
							vm.loadStatus = 'noMore';
						}
						if(refresh) {
							uni.stopPullDownRefresh();
						}
					},
					fail: (res) => {
						uni.showModal({
							content: '加载数据失败',
							showCancel: false
						})
					},
					complete: () => {
						uni.hideLoading();
					}
				});
			}
		}
	}
</script>

<style>
	.box-video {
		padding-top: 10upx;
	}
	.box-list {
		display: flex;
		justify-content: space-between;
		flex-wrap: wrap;
		justify-content: space-between;
	}
	.box-list .item-list{
		width: 49%;
		margin-bottom: 20upx;
	}
	.box-list .item-list .item-img {
		border-radius: 6upx;
		display: block;
		height: 150px;
		position: relative;
		overflow: hidden;
		text-align: center;
	}
	.box-list .item-list .item-title {
		margin: 6upx 0 10upx;
		width: 100%;
		/* text-overflow: ellipsis;
		white-space: nowrap;
		overflow: hidden;
		display: flex;
		justify-content: space-between; */
	}
	.box-list .item-list .item-title .t-info {
		width: 100%;
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
		display: block;
	}
	.box-list .item-list .item-title em {
		font-style: normal;
		color: #d349f7;
	}
	.box-list .item-list .item-img span{
		color: #f97937;
		font-weight: 600;
		position: absolute;
		right: 10upx;
		bottom: 10upx;
	}
</style>
