<template>
	<view class="content">
		<!-- #ifdef APP-PLUS -->
		<view class="status_bar"><view class="top_view"></view></view> 
		<!-- #endif -->

		<view class="task-title">
			任务中心
		</view>
		<view class="shuju t-cont">
			<view class="s-warp">
				<text>已邀请</text>
				<view class="num">{{ type || 0}}</view>
			</view>
			<view class="s-warp">
				<text>今日可观影次数</text>
				<view v-if="type" class="num">不限</view>
				<view v-else class="num">10</view>
			</view>
			<view class="s-warp">
				<text>剩余观影次数</text>
				<view v-if="type" class="num">不限</view>
				<view v-else class="num">{{ 10 - playArr.length }}</view>
			</view>
		</view>
		<view class="c-btn t-cont">
			<view class="btn-l" @click="goRoute('extension')">
				我的推广
			</view>
			<view class="btn-l" @click="goRoute('invit')">
				邀请好友
			</view>
		</view>
		
		<view class="guanggao guanggao-2">
			<view class="g-list" v-for="(item, idx) in guangaoList" :key="idx" @click="goOut(item.url)">
				<image class="g-img" :src="$resource + '/banner/' + item.pic" mode="widthFix"></image>
			</view>
		</view>
		
		<view class="t-cont jieso">
			<view class="j-title">
				我的福利
			</view>
			<text>新人奖励，每日观影次数 + 10</text>
		</view>
		
		<view class="t-cont jieso">
			<view class="j-title">
				推广任务
			</view>
			<text>1.好友成功下载APP并登陆，可永久观影</text>
		</view>
		
		<!-- #ifdef H5 -->
		<view class="status_tabar"></view>  
		<!-- #endif -->
	</view>
</template>

<script>
	import {uniIcons} from '@dcloudio/uni-ui'
	export default {
		components: {uniIcons},
		data() {
			return {
				type: '',
				playArr: [],
				guangaoList: []
			}
		},
		onLoad() {
			this.getGuangao();
		},
		onShow() {
			var date = new Date();
			var key = (date.getMonth() + 1) +'-'+ date.getDate();
			var playArr = uni.getStorageSync(key);
			this.playArr = playArr || [];
			var value = uni.getStorageSync('login-info');
			if (value) {
				this.type = value.type;
			}
		},
		methods: {
			goRoute(type) {
				uni.navigateTo({
					url: '/pages/my/' + type
				});
			},
			getGuangao() {
				var list = this.$store.state.guanggaoList;
				this.guangaoList = list.filter(item => item.type == 3);
			},
			goOut(url) {
				if(!url) {
					return
				};
				// #ifdef APP-PLUS
				plus.runtime.openURL(url);
				// #endif
				// #ifndef APP-PLUS
				window.location.href = url;
				//#endif
			}
		}
	}
</script>

<style>
	.task-title {
		font-size: 34upx;
		text-align: center;
		padding-top: 20upx;
	}
	.t-cont{
		background-color: #1e1e1e;
	}
	.shuju{
		padding: 20upx 0;
		display: flex;
		text-align: center;
		justify-content: space-between;
		margin-top: 30upx;
	}
	.shuju .s-warp{
		width: 33.333%;
		font-size: 26upx;
	}
	.shuju .num{
		color: #ff09af;
		font-size: 20px;
		font-weight: bold;
	}
	.c-btn {
		height: 120upx;
		padding: 15upx 0;
	}
	.c-btn .btn-l{
		float: left;
		width: 40%;
		margin-left: 7%;
		text-align: center;
		color: #ff09af;
		font-weight: bold;
		border: 1px solid #ff09af;
		height: 70upx;
		line-height: 68upx;
		border-radius: 35upx;
	}
	.jieso{
		margin-top: 20upx;
		padding: 20upx 30upx;
		font-size: 28upx;
	}
	.j-title {
		color: #ff09af;
		font-size: 30upx;
		font-weight: 600;
		margin-bottom: 10upx;
	}
</style>
