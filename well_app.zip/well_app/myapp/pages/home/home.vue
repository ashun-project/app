<template>
	<view class="">
		<!-- #ifdef APP-PLUS -->  
		<view class="status_bar"><view class="top_view"></view></view>
		<!-- #endif -->
		
		<view class="top-v w-94">
			<view class="search" @click="goRoute">
				<view class="ico-sear">
					<uni-icons type="search" size="20" color="#d349f7" />
				</view>
				<input class="search-txt" disabled type="text" value="" />
			</view>
			<view class="bars">
				<show-bar class="bar-list" @selectMenu="selectMenu"></show-bar>
			</view>
		</view>
		
		<view class="guanggao w-94">
			<view class="g-list" v-for="(item, idx) in guangaoList" :key="idx" @click="goOut(item.url)">
				<image class="g-img" :src="$resource + '/banner/' + item.pic" mode="widthFix"></image>
			</view>
		</view>
		
		<view class="hot-bar w-94">
			<view class="list-item" v-for="(item, idx) in hotMenu" :key="idx" @click="selectMenu(item.type)">
				<image :src="'../../static/img/bar'+ (idx+1) +'.png'" class="img" mode="widthFix"></image>
				<text class="i-txt">{{ item.category }}</text>
			</view>
		</view>
		
		<view class="box-video w-94">
			<view class="box-title">
				<view class="i-t">
					<uni-icons type="videocam" size="20" color="#856669" />
					<text>最新片源</text>
				</view>
				<view class="" @click="showNewList">
					更多
				</view>
			</view>
			<view class="box-list">
				<view class="item-list" v-for="(item, idx) in dataList" :key="idx" @click="goDetail(item)">
					<view class="item-img">
						<image class="img" :src="item.img" mode="widthFix" @error="imageError"></image>
						<span>{{ (item.pay_total / $payCont).toFixed(2) }}</span>
					</view>
					<view class="item-title">{{ item.title }}</view>
				</view>
			</view>
		</view>
		<view class="vip-txt">
			<view class="vip-ico">
				<image class="img" src="../../static/img/vip.png" mode="widthFix"></image>
			</view>
			<text>推广一人无限观影&nbsp;&nbsp;任性看</text>
		</view>
		
		<!-- #ifdef H5 -->
		<view class="status_tabar"></view>  
		<!-- #endif -->
	</view>
</template>

<script>
	import {uniIcons} from '@dcloudio/uni-ui'
	import showBar from '@/components/show-bar/bar.vue'
	export default {
		components: {uniIcons,showBar},
		data() {
			return {
				title: 'Hello',
				dataList: [],
				hotMenu: [],
				guangaoList: []
			}
		},
		onLoad() {
			this.setHotMenu();
			this.getList();
			this.getGuangao();
		},
		methods: {
			getList() {
				var vm = this;
				uni.showLoading({
					title: 'loading'
				});
				uni.request({
					url: this.$resource + '/app/tList',
					method: 'POST',
					data: {pageSize: 9},
					header:{
						'content-type':'application/x-www-form-urlencoded'
					},
					success: (res) => {
						if (!vm.hotMenu.length) {
							vm.setHotMenu()
						}
						vm.dataList= res.data.data || [];
					},
					fail: (res) => {
						uni.showModal({
							content: '加载数据失败',
							showCancel: false
						})
					},
					complete: () => {
						uni.hideLoading();
					}
				});
			},
			getGuangao() {
				var list = this.$store.state.guanggaoList;
				this.guangaoList = list.filter(item => item.type == 1);
			},
			setHotMenu() {
				var storeMenu = this.$store.state.menu;
				this.hotMenu = storeMenu.filter(item => item.hot);
			},
			goRoute() {
				uni.navigateTo({
					url: '/pages/search/search'
				});
			},
			showNewList() {
				uni.switchTab({
					url: '/pages/new/new'
				})
			},
			selectMenu(type) {
				uni.navigateTo({
					url: '/pages/list/list?type=' + type
				});
			},
			imageError (e) {
				console.error('image发生error事件，携带值为' + e.detail.errMsg)
			},
			goDetail(item) {
				this.$store.commit('playDataChange', item);
				// this.$store.commit({
				//                     type: 'playDataChange',
				//                     rssItem: item
				//                 })
				uni.navigateTo({
					url: '/pages/play/play?id=' + item.id
				});
			},
			goOut(url) {
				if(!url) {
					return
				};
				// #ifdef APP-PLUS
				plus.runtime.openURL(url);
				// #endif
				// #ifndef APP-PLUS
				window.location.href = url;
				//#endif
			}
		}
	}
</script>

<style>
	/* .content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	} */
	.top-v{
		padding-top: 20upx;
		display: flex;
		width: 100%;
		padding-bottom: 10upx;
	}
	.top-v .bars{
		width: 60upx;
		height: 60upx;
		line-height: 60upx;
	}
	.search{
		background-color: #1e1e1e;
		height: 60upx;
		line-height: 60upx;
		width: 90%;
		margin: 0 auto;
		border-radius: 30upx;
		overflow: hidden;
		position: relative;
		flex: 1;
	}
	.search .ico-sear{
		position: absolute;
		left: 20upx;
		top: 2upx;
	}
	.search .search-txt{
		width: 100%;
		height: 100%;
		color: #fff;
		padding: 10upx 0;
		padding-left: 68upx;
		line-height: 40upx;
	}
	.hot-bar {
		display: flex;
		padding: 40upx 0;
	}
	.hot-bar .list-item {
		width: 20%;
		display: flex;
		align-items: center;
		justify-content: center;
		flex-wrap: wrap;
	}
	.hot-bar .img {
		max-width: 90upx;
		width: 100%;
	}
	.hot-bar .i-txt {
		width: 100%;
		display: block;
		color: #fff;
		text-align: center;
		padding-top: 5px;
		font-size: 25upx;
		color: #CCCCCC;
	}
	.box-video {
		/* width: 100%; */
	}
	.box-title {
		display: flex;
		justify-content: space-between;
		height: 78upx;
		line-height: 72upx;
	}
	.box-title .i-t{
		display: flex;
		align-items: center;
	}
	.box-list {
		display: flex;
		justify-content: space-between;
		flex-wrap: wrap;
	}
	.box-list .item-list{
		width: 32%;
		text-align: center;
		/* height: 200px; */
	}
	.box-list .item-list .item-img {
		border-radius: 6upx;
		display: block;
		height: 150px;
		position: relative;
		overflow: hidden;
	}
	.box-list .item-list .item-title {
		display: block;
		margin: 6upx 0 10upx;
		width: 100%;
		text-overflow: ellipsis;
		white-space: nowrap;
		overflow: hidden;
	}
	.box-list .item-list .item-img span{
		color: #f97937;
		font-weight: 600;
		position: absolute;
		right: 10upx;
		bottom: 10upx;
	}
	.vip-txt {
		display: flex;
		justify-content: center;
		font-size: 22upx;
		color: #999;
		line-height: 21px;
		padding-top: 10upx;
	}
	.vip-txt .vip-ico{
		width: 20px;
		/* padding-top: 8upx; */
	}
</style>
