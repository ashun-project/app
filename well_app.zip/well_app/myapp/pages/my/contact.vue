<template>
	<view>
		<!-- #ifdef APP-PLUS -->
		<view class="status_bar"><view class="top_view"></view></view> 
		<!-- #endif -->
		
		<view class="t-head">
			<view class="head-cont">
				<view class="head-back" @click="goRouteBack">
					<uni-icons type="arrowleft" size="20" color="#ffffff" />
				</view>
				<view class="head-title">
					联系我们
				</view>
				<view class="head-r">
					<!-- <image class="img" src="../../static/img/history.png" mode="widthFix"></image> -->
				</view>
			</view>
		</view>
		
		<view class="c-list">
			<view class="c-title">
				邮箱：
			</view>
			<text>{{ email }}</text>
		</view>
		<view class="c-list">
			<view class="c-title">
				TG飞机：
			</view>
			<text>{{ telegram }}</text>
		</view>
		<view class="c-list">
			<view class="c-title">
				QQ:
			</view>
			<text>{{ qq }}</text>
		</view>
	</view>
</template>

<script>
	import {uniIcons} from '@dcloudio/uni-ui'
	export default {
		components: {uniIcons},
		data() {
			return {
				email: "",
				qq: "",
				telegram: ""
			}
		},
		onLoad() {
			this.getInfo();
		},
		methods: {
			goRouteBack(url) {
				// #ifdef APP-PLUS
				uni.navigateBack();
				// #endif
				// #ifdef H5
				window.history.back()
				// #endif
			},
			getInfo() {
				var vm = this;
				uni.request({
					url: this.$resource + '/app/appInfo',
					method: 'POST',
					header:{
						'content-type':'application/x-www-form-urlencoded'
					},
					success: (res) => {
						var obj = res.data.data || {};
						vm.email = obj.email;
						vm.qq = obj.qq;
						vm.telegram = obj.telegram;
					}
				});
			}
		}
	}
</script>

<style>
	.c-list {
		background-color: #1e1e1e;
		padding: 20upx;
		margin-top: 40upx;
		font-size: 30upx;
	}
	.c-list .c-title {
		color: #ff09af;
		font-size: 30upx;
		font-weight: 600;
		margin-bottom: 10upx;
	}
</style>
