<template>
	<view class="content">
		<!-- #ifdef APP-PLUS -->
		<view class="status_bar"><view class="top_view"></view></view>
		<!-- #endif -->
		
		<view class="t-head">
			<view class="head-cont">
				<view class="head-back" @click="goRouteBack">
					<uni-icons type="arrowleft" size="20" color="#ffffff" />
				</view>
				<view class="head-title">
					邀请好友
				</view>
				<view class="head-r">
					<!-- <image class="img" src="../../static/img/history.png" mode="widthFix"></image> -->
				</view>
			</view>
		</view>
		
		<view class="qrimg">
		    <tki-qrcode
			cid="26561"
		    ref="qrcode"
			icon="../../static/img/logo.png"
		    :val="qrVal"
			:iconSize="30"
			:size="300"/></tki-qrcode>
		</view>
		<view class="my-tg">
			<text>我的推广码：<em>{{ invitation }}</em></text>
		</view>
		<view class="btn-copy">
			<button type="default" @click="goCopy(1)">复制下载连接</button>
			<button type="default" @click="goCopy(2)">复制邀请码</button>
		</view>
		<view class="tip">
			<view class="tip-title">
				邀请步骤
			</view>
			<text>
				1. 复制下载连接发送给好友
				<br>
				2. 复制邀请吗发送给好友
				<br>
				3. 好友下载app后通过邀请码注册
				<br>
				4. 刷新登录，或重新登录即可
			</text>
			
			<view class="link-d">
				下载连接：{{ qrVal }}
			</view>
		</view>
	</view>
</template>

<script>
	import {uniIcons} from '@dcloudio/uni-ui'
	import tkiQrcode from "@/components/tki-qrcode/tki-qrcode.vue"
	export default {
		components: {uniIcons, tkiQrcode},
		data() {
			return {
				qrVal: '',
				invitation: ''
			}
		},
		onLoad() {
			var value = uni.getStorageSync('login-info');
			if (value) {
				this.invitation = value.invitation;
			}
			var vm = this;
			uni.showLoading({
				title: 'loading'
			});
			uni.request({
				url: this.$resource + '/app/appInfo',
				method: 'POST',
				header:{
					'content-type':'application/x-www-form-urlencoded'
				},
				success: (res) => {
					var data = res.data.data || {};
					vm.qrVal = data.qrLink;
					vm.$nextTick(function(){
						vm.$refs.qrcode._makeCode()
					})
					// debugger
				},
				fail: (res) => {
					uni.showModal({
						content: '加载数据失败',
						showCancel: false
					})
				},
				complete: () => {
					uni.hideLoading();
				}
			});
		},
		methods: {
			goRouteBack(url) {
				// #ifdef APP-PLUS
				uni.navigateBack();
				// #endif
				// #ifdef H5
				window.history.back()
				// #endif
			},
			goCopy(type) {
				// #ifdef APP-PLUS
				if(type == 1) {
					var data = this.qrVal;
				} else {
					var data = this.invitation;
				}
				uni.setClipboardData({
					data: '23423423',
					success: function () {
						console.log('success');
					}
				})
				// #endif
				
				// #ifdef H5
				uni.showModal({
					content: '不支持网页版复制',
					showCancel: false
				})
				//#endif
			}
		}
	}
</script>

<style>
	.qrimg{
		width: 320upx;
		height: 320upx;
		padding: 10upx;
		background-color: #fff;
		margin: 60upx auto 0;
	}
	.my-tg{
		text-align: center;
		font-size: 34upx;
		padding-top: 10upx;
	}
	.my-tg em{
		color: #d349f7;
		font-style: normal;
	}
	.btn-copy {
		width: 100%;
		padding-top: 70upx;
		display: flex;
		justify-content: space-between;
		/* background-color: #1e1e1e; */
	}
	.btn-copy button {
		/* margin-top: 20upx; */
		font-size: 28upx;
		background-color: #ff09af;
		color: #fff;
		width: 40%;
	}
	.btn-copy button:active{
		background-color: #ff34bd;
	}
	.tip {
		padding: 20upx 30upx;
		background-color: #1e1e1e;
		margin-top: 50upx;
	}
	.tip-title {
		color: #ff09af;
		font-size: 30upx;
		font-weight: 600;
		margin-bottom: 10upx;
	}
	.link-d {
		color: #ff09af;
		padding: 20upx 0;
	}
</style>
