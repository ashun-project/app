<template>
	<view>
		<!-- #ifdef APP-PLUS -->
		<view class="status_bar"><view class="top_view"></view></view>
		<!-- #endif -->
		
		<view class="t-head">
			<view class="head-cont">
				<view class="head-back" @click="goRouteBack">
					<uni-icons type="arrowleft" size="20" color="#ffffff" />
				</view>
				<view class="head-title">
					
				</view>
				<view class="head-r">
					用户注册
				</view>
			</view>
		</view>
		
		<view class="t-tip w-94">
			手机号注册
		</view>
		
		<view class="login w-94">
			<view class="login-list">
				<view class="lab-l">
					<text>国家/地区</text>
				</view>
				<view class="cont-l">
					<text>中国大陆</text>
				</view>
			</view>
			<view class="login-list">
				<view class="lab-l">
					<uni-icons type="phone" size="14" color="#ccc" />
					<text>+86</text>
				</view>
				<view class="cont-l">
					<input class="uni-input" v-model="formData.account" placeholder="请输入手机号码" />
				</view>
			</view>
			<view class="login-list no-txt">
				<view class="cont-l">
					<uni-icons type="locked" size="18" color="#ccc" />
					<input class="uni-input" v-model="formData.password" type="password" placeholder="请输入密码" />
				</view>
			</view>
			<view class="login-list last-l no-txt">
				<view class="cont-l">
					<uni-icons type="personadd" size="18" color="#ccc" />
					<input class="uni-input" v-model="formData.recommend" placeholder="请输入邀请码" />
				</view>
			</view>
			<text class="tip">邀请码非必填参数</text>
		</view>
		
		<view class="w-94 confirm-btn">
			<button type="default" @click="comfirmBtn">注册</button>
		</view>
	
	</view>
</template>

<script>
	import {uniIcons} from '@dcloudio/uni-ui'
	export default {
		components: {uniIcons},
		data() {
			return {
				formData: {
					account: '',
					password: '',
					recommend: ''
				}
			}
		},
		methods: {
			showChat() {
				uni.showModal({
					content: '请联系客服',
					showCancel: false
				})
			},
			goRouteBack(url) {
				// #ifdef APP-PLUS
				uni.navigateBack();
				// #endif
				// #ifdef H5
				window.history.back()
				// #endif
			},
			comfirmBtn() {
				var vm = this;
				var rel = /^[1]([2-9])[0-9]{9}$/;
				var err = '';
				if (!(rel.test(this.formData.account))) {
				    err = '手机号码输入不规范';
				}
				if (!this.formData.password) {
				    err = '请输入密码';
				}
				if (!this.formData.account) {
				    err = '请输入手机号';
				}
				if (err) {
					uni.showModal({
						content: err,
						showCancel: false
					})
					return
				}
				uni.request({
					url: this.$resource + '/app/register',
					method: 'POST',
					data: this.formData,
					header:{
						'content-type':'application/x-www-form-urlencoded'
					},
					success: (res) => {
						if (res.data.code == 1) {
							uni.showModal({
								content: res.data.message,
								showCancel: false
							})
						} else {
							uni.showToast({
							    title: '注册成功',
							    duration: 2000,
								position: 'top',
								icon: 'success'
							});
							uni.setStorageSync('login-info', res.data.data);
							setTimeout(function() {
								uni.switchTab({
								    url: '/pages/my/my'
								});
							},1500)
						}
					},
					fail: (res) => {
						uni.showModal({
							content: '加载数据失败',
							showCancel: false
						})
					},
					complete: () => {
						uni.hideLoading();
					}
				});
			}
		}
	}
</script>

<style>
	.t-tip {
		margin-top: 60upx;
		margin-bottom: 30upx;
		font-size: 40upx;
	}
	.login {
		background-color: #1e1e1e;
		padding: 20upx 30upx;
	}
	.login-list {
		display: flex;
		align-items: center;
		height: 120upx;
		line-height: 120upx;
		border-bottom: 1px solid #292929;
	}
	/* .login .last-l {
		border-width: 0;
	} */
	.login-list .lab-l {
		width: 160upx;
		position: relative;
	}
	.login-list .lab-l::after{
		content: '';
		height: 30upx;
		width: 1px;
		background: #928736;
		position: absolute;
		right: 20upx;
		top: 45upx;
		opacity: 0.5;
	}
	
	.login-list .cont-l {
		flex: 1;
	}
		
	.no-txt .cont-l{
		display: flex;
		align-items: center;
	}
	.no-txt .cont-l .uni-input{
		padding-left: 20upx;
		flex: 1;
	}
	
	.confirm-btn {
		margin-top: 40upx;
	}
	.confirm-btn button{
		border-radius: 40upx;
		color: #d349f7;
		background-color: #1e1e1e;
	}
	.confirm-btn button:active{
		background-color: #222222;
	}
	.caozuo {
		display: flex;
		justify-content: space-between;
		width: 80%;
		margin: 60upx auto 0;
	}
	.tip{
		line-height: 60upx;
		color: #c74d4d;
	}
</style>
