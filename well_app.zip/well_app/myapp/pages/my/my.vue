<template>
	<view class="content my">
		<!-- #ifdef APP-PLUS -->
		<view class="status_bar"><view class="top_view"></view></view>
		<!-- #endif -->

	<!-- 	<view class="top-set">
			<uni-icons type="more-filled" size="23" color="#807f7f" />
		</view> -->

		<view class="my-top">
			<view class="tx">
				<image class="img" src="../../static/img/tx.png" mode="widthFix"></image>
			</view>
			<view v-if="user.account" class="info-d">
				<view class="account">
					{{ user.account }}
				</view>
				<view class="tuig" @click="goCopy">
					<text>{{ user.invitation }}</text>
					<uni-icons class="fuz" type="map" size="14" color="#d349f7" />
				</view>
				<view class="loading-cont" @click="refreshLogin">
					<view class="" v-if="!refresh">
						<uni-icons type="reload" size="20" color="#999" />
					</view>
					<view class="" v-else>
						<uni-load-more :status="status" :contentText="contentText"/>
					</view>
				</view>
			</view>
			<view v-else class="info">
				<button type="default" size="mini" @click="goRoute('login')">登录</button>
				<button type="default" size="mini" @click="goRoute('register')">注册</button>
			</view>
		</view>
		
		<view class="vip-txt">
			<view class="vip-ico">
				<image class="img" src="../../static/img/vip.png" mode="widthFix"></image>
			</view>
			<text v-if="user.type">今日可无限观影&nbsp;&nbsp;任性看</text>
			<text v-else>今日可观影10部&nbsp;&nbsp;推广一人后无限观影&nbsp;&nbsp;任性看</text>
		</view>
		
		<view class="moshi">
			<view class="m-list" @click="goRoute('extension')">
				<view class="m-pic">
					<image class="img" src="../../static/img/t1.png" mode="widthFix"></image>
				</view>
				<text>我的推广</text>
			</view>
			<view class="m-list" @click="goRoute('invit')">
				<view class="m-pic">
					<image class="img" src="../../static/img/t2.png" mode="widthFix"></image>
				</view>
				<text>邀请好友</text>
			</view>
			<view class="m-list">
				<view class="m-pic">
					<image class="img" src="../../static/img/t4.png" mode="widthFix"></image>
				</view>
				<text>模式</text>
			</view>
			<view class="m-list" @click="loginOut">
				<view class="m-pic">
					<image class="img" src="../../static/img/t3.png" mode="widthFix"></image>
				</view>
				<text>退出</text>
			</view>
		</view>
		
		<view class="guanggao guanggao-2">
			<view class="g-list" v-for="(item, idx) in guangaoList" :key="idx" @click="goOut(item.url)">
				<image class="g-img" :src="$resource + '/banner/' + item.pic" mode="widthFix"></image>
			</view>
		</view>
		
		<view class="lie">
			<view class="l-list" @click="goRoute('history')">
				<view class="l-pic">
					<image class="img" src="../../static/img/lishi.png" mode="widthFix"></image>
				</view>
				<text>观看历史</text>
			</view>
			<view class="l-list" @click="goRoute('collection')">
				<view class="l-pic">
					<image class="img" src="../../static/img/fav.png" mode="widthFix"></image>
				</view>
				<text>我的收藏</text>
			</view>
			<view class="l-list" @click="goRoute('contact')">
				<view class="l-pic">
					<image class="img" src="../../static/img/about.png" mode="widthFix"></image>
				</view>
				<text>联系我们</text>
			</view>
		</view>
		
		<!-- #ifdef H5 -->
		<view class="status_tabar"></view>  
		<!-- #endif -->
	</view>
</template>

<script>
	import {uniIcons, uniLoadMore} from '@dcloudio/uni-ui'
	export default {
		components: {uniIcons, uniLoadMore},
		data() {
			return {
				user: {
					account: '',
					password: '',
					type: ''
				},
				refresh: false,
				status: 'loading',
				contentText: {
					contentdown: '',
					contentnomore: '',
					contentrefresh: ''
				},
				guangaoList: []
			}
		},
		onLoad() {
			this.getGuangao();
		},
		onShow() {
			var value = uni.getStorageSync('login-info');
			if (value) {
				this.user.account = value.userName;
				this.user.password = value.password;
				this.user.type = value.type;
				this.user.invitation = value.invitation;
			}
		},
		methods: {
			goCopy(data) {
				// #ifdef APP-PLUS
				uni.setClipboardData({
					data: '23423423',
					success: function () {
						console.log('success');
					}
				})
				// #endif
				
				// #ifdef H5
				uni.showModal({
					content: '不支持网页版复制',
					showCancel: false
				})
				//#endif
			},
			goRoute(type) {
				uni.navigateTo({
					url: '/pages/my/' + type
				});
			},
			refreshLogin() {
				var vm = this;
				this.refresh = true;
				uni.request({
					url: this.$resource + '/app/login',
					method: 'POST',
					data: this.user,
					header:{
						'content-type':'application/x-www-form-urlencoded'
					},
					success: (res) => {
						if (res.data.code == 0) {
							uni.setStorageSync('login-info', res.data.data);
							setTimeout(function() {
								uni.showToast({
								    title: '刷新成功',
								    duration: 2000,
									position: 'top',
									icon: 'none'
								});
								vm.refresh = false;
							}, 1000)
						} else {
							vm.refresh = false;
						}
					}
				});
			},
			loginOut() {
				uni.request({
					url: this.$resource + '/app/loginOut',
					method: 'POST',
					data: this.user,
					header:{
						'content-type':'application/x-www-form-urlencoded'
					},
					success: (res) => {
						uni.showToast({
						    title: '退出成功',
						    duration: 2000,
							position: 'top',
							icon: 'success'
						});
						uni.removeStorageSync('login-info');
						this.user.password = ''
						this.user.type = ''
						this.user.account = ''
						this.user.invitation = ''
					}
				});
			},
			getGuangao() {
				var list = this.$store.state.guanggaoList;
				this.guangaoList = list.filter(item => item.type == 4);
			},
			goOut(url) {
				if(!url) {
					return
				};
				// #ifdef APP-PLUS
				plus.runtime.openURL(url);
				// #endif
				// #ifndef APP-PLUS
				window.location.href = url;
				//#endif
			}
		}
	}
</script>

<style>
	/* .my {
		position: relative;
	}
	.top-set {
		position: absolute;
		top: 20upx;
		right: 30upx;
		z-index: 20;
		line-height: 40upx;
	} */
	.my-top {
		position: relative;
		display: flex;
		justify-content: space-between;
		padding: 50upx 20upx;
	}
	.my-top .tx {
		width: 130upx;
	}
	.my-top .info {
		flex: 1;
		display: flex;
		align-items: center;
		justify-content: left;
	}
	.my-top button{
		margin: 0;
		margin-left: 40upx;
		color: #d349f7;
		background-color: #1e1e1e;
	}
	.my-top .info-d {
		flex: 1;
		margin-left: 20upx;
		padding-top: 10upx;
		position: relative;
	}
	.my-top .tuig {
		height: 46upx;
		border-radius: 25upx;
		background-color: #1e1e1e;
		width: 200upx;
		padding-left: 20upx;
		line-height: 46upx;
	}
	.my-top .info-d .account {
		font-size: 34upx;
		margin-bottom: 4upx;
	}
	.my-top .tuig .fuz {
		float: right;
		margin-right: 20upx;
	}
	.my-top button:active{
		background-color: #3c3b3b;
	}
	.info-d .loading-cont{
		position: absolute;
		top: 30upx;
		right: 0upx;
		width: 80upx;
	}
	.moshi {
		display: flex;
		justify-content: space-between;
		margin-top: 50upx;
		background-color: #1e1e1e;
		padding: 30upx 0;
	}
	.moshi .m-list{
		width: 25%;
		text-align: center;
	}
	.moshi .m-list .m-pic {
		width: 50%;
		margin: 0 auto;
	}
	.lie {
		background-color: #1e1e1e;
		margin-top: 20upx;
	}
	.l-list {
		display: flex;
		align-items: center;
		height: 80upx;
		border-bottom: 1px solid #232121;
		padding: 0 20upx;
	}
	.l-list .l-pic {
		width: 20px;
		height: 20px;
		margin-right: 20upx;
	}
	.vip-txt {
		display: flex;
		justify-content: center;
		font-size: 22upx;
		color: #999;
		line-height: 21px;
		padding-top: 10upx;
	}
	.vip-txt .vip-ico{
		width: 20px;
		/* padding-top: 8upx; */
	}
</style>
