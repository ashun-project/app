<template>
	<view>
		<!-- #ifdef APP-PLUS -->
		<view class="status_bar"><view class="top_view"></view></view> 
		<!-- #endif -->
		
		<view class="t-head">
			<view class="head-cont">
				<view class="head-back" @click="goRouteBack">
					<uni-icons type="arrowleft" size="20" color="#ffffff" />
				</view>
				<view class="head-title">
					我的收藏
				</view>
				<view class="head-r">
					<!-- <image class="img" src="../../static/img/history.png" mode="widthFix"></image> -->
				</view>
			</view>
		</view>
		<view v-if="!listData.length" class="no-data">
			<text>暂无数据</text>
		</view>
		<view class="c-list" v-for="item in listData" :key="item.id" @click="goRoute(item)">
			<view class="c-title">
				{{ item.type }}
			</view>
			<text class="l-tit">{{ item.title }}</text>
			<view class="arr-rig">
				<uni-icons type="arrowright" size="20" color="#999" />
			</view>
		</view>
	</view>
</template>

<script>
	import {uniIcons} from '@dcloudio/uni-ui'
	export default {
		components: {uniIcons},
		data() {
			return {
				listData: []
			}
		},
		onShow() {
			var collection = uni.getStorageSync('store-collection') || [];
			var arr = [];
			for (var i = 0; i< collection.length; i++) {
				var fil = arr.filter(function(item) {
					return item.id == collection[i].id
				})
				if (!fil.length) {
					arr.push(collection[i]);
				}
			}
			this.listData = arr;
			uni.setStorage({
			    key: 'store-collection',
			    data: arr
			});
		},
		methods: {
			goRouteBack(url) {
				// #ifdef APP-PLUS
				uni.navigateBack();
				// #endif
				// #ifdef H5
				window.history.back()
				// #endif
			},
			goRoute(item) {
				uni.showLoading({
					title: 'loading'
				});
				uni.request({
					url: this.$resource + '/app/tList',
					method: 'POST',
					data: {pageSize: 1, id: item.id},
					header:{
						'content-type':'application/x-www-form-urlencoded'
					},
					success: (res) => {
						var obj = res.data.data;
						if (obj[0]) {
							this.$store.commit('playDataChange', obj[0]);
							uni.navigateTo({
								url: '/pages/play/play?id=' + item.id
							});
						} else {
							uni.showModal({
								content: '没有找到这条数据',
								showCancel: false
							})
						}
					},
					fail: (res) => {
						uni.showModal({
							content: '加载数据失败',
							showCancel: false
						})
					},
					complete: () => {
						uni.hideLoading();
					}
				});
			}
		}
	}
</script>

<style>
	.c-list {
		background-color: #1e1e1e;
		padding: 20upx;
		margin-top: 20upx;
		font-size: 30upx;
		position: relative;
	}
	.c-list:active{
		background-color: #2b2b2b;
	}
	.c-list .c-title {
		color: #ff09af;
		font-size: 30upx;
		font-weight: 600;
		margin-bottom: 10upx;
	}
	.l-tit{
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		display: block;
		padding-right: 30upx;
	}
	.arr-rig{
		position: absolute;
		top: 50%;
		right: 10upx;
		height: 60upx;
		margin-top: -30upx;
	}
	.no-data{
		text-align: center;
		line-height: 100upx;
		color: #696969;
	}
</style>
