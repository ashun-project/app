<template>
	<view class="content">
		<!-- #ifdef APP-PLUS -->
		<view class="status_bar"><view class="top_view"></view></view>
		<!-- #endif -->

		<view class="t-head">
			<view class="head-cont">
				<view class="head-back" @click="goRouteBack">
					<uni-icons type="arrowleft" size="20" color="#ffffff" />
				</view>
				<view class="head-title">
					<input v-model="searchVal" class="uni-input" type="text" />
				</view>
				<view class="head-r" @click="tagClick()">
					<uni-icons type="search" size="20" color="#d349f7" />
				</view>
			</view>
		</view>
		
		<view class="tag-warp w-94" v-if="dataList.length <= 0">
			<view class="tag-list">
				<uni-tag v-for="(item, key) in tagList" :key="key" :text="item" class="tag-txt" @click="tagClick(item)"></uni-tag>
				<uni-tag text=""></uni-tag>
				<view class="my-tag">占位</view>
			</view>
		</view>
		
		<view class="box-video w-94">
			<view class="box-list">
				<view class="item-list" v-for="item in dataList" :key="item.id" @click="goDetail(item)">
					<view class="item-img">
						<image class="img" :src="item.img" mode="widthFix"></image>
					</view>
					<view class="item-title">
						<text class="t-info">{{ item.title }}</text>
						<text class="t-info"><em>{{ (item.pay_total / $payCont).toFixed(2) }}</em>分<strong>·</strong><em>{{ item.pay_total }}</em>播放量</text>
					</view>
				</view>
			</view>
		</view>
		
		<view class="" v-if="dataList.length">
			<uni-load-more :status="loadStatus" :contentText="contentText" @clickLoadMore="clickLoadMore"></uni-load-more>
		</view>
		<!-- #ifdef H5 -->
		<view class="status_tabar"></view>  
		<!-- #endif -->
	</view>
</template>

<script>
	import {uniIcons, uniLoadMore,uniTag} from '@dcloudio/uni-ui'
	export default {
		components: {uniIcons, uniLoadMore,uniTag},
		data() {
			return {
				searchVal: '',
				loadStatus: 'more',
				dataList: [],
				page: 1,
				tagList: ['强奸', '无码', '欧美', '乱伦', '少妇', '姐姐', '巨乳', '人妻'],
				contentText: {
					contentdown: '点击加载更多',
					contentrefresh: '正在加载...',
					contentnomore: '我是有底线的'
				}
			}
		},
		onLoad(option) {
		
		},
		onPullDownRefresh() {
			this.page = 1;
			this.loadStatus = 'loading';
			this.getList(true);
		},
		onReachBottom() {
			this.getList();
		},
		methods: {
			goRouteBack(url) {
				// #ifdef APP-PLUS
				uni.navigateBack();
				// #endif
				// #ifdef H5
				window.history.back()
				// #endif
			},
			clickLoadMore() {
				this.getList();
			},
			goDetail(item) {
				this.$store.commit('playDataChange', item);
				uni.navigateTo({
					url: '/pages/play/play?id=' + item.id
				});
			},
			tagClick(val) {
				if (val) {
					this.searchVal = val;
				}
				if (!this.searchVal) {
					this.dataList = [];
					return
				}
				this.loadStatus = 'more';
				this.page = 1;
				this.getList();
			},
			getList(refresh) {
				if (this.loadStatus === 'noMore') {
					return;
				};
				var vm = this;
				this.loadStatus = 'loading';
				uni.request({
					url: this.$resource + '/app/tList',
					method: 'POST',
					data: {pageSize: 9, page: vm.page, search: vm.searchVal},
					header:{
						'content-type':'application/x-www-form-urlencoded'
					},
					success: (res) => {
						var list = res.data.data || [];
						var newList = vm.dataList.concat(list);
						vm.$set(vm, 'dataList', newList);
						vm.loadStatus = 'more';
						vm.page += 1;
						if (list.length < 9) {
							vm.loadStatus = 'noMore';
						}
						if(refresh) {
							uni.stopPullDownRefresh();
						}
					},
					fail: (res) => {
						uni.showModal({
							content: '加载数据失败',
							showCancel: false
						})
					},
					complete: () => {
						uni.hideLoading();
					}
				});
			}
		}
	}
</script>

<style>
	.head-title {
		flex: 1;
		padding: 10upx 20upx;
		height: 60upx;
		background: #1E1E1E;
		border-radius: 30upx;
	}
	.head-title input{
		width: 100%;
		height: 100%;
		background: none;
		padding-left: 10upx;
	}
	.tag-list {
		display: flex;
		padding: 20upx 0;
		flex-wrap: wrap;
		justify-content: space-between;
	}
	.tag-list .tag-txt {
		margin:10upx 0;
		background-color: #1e1e1e;
		border-color: #1e1e1e;
	}
	.tag-list .tag-txt >>> span {
		color: #ccc;
	}
	.tag-list .tag-txt:active{
		background: #333;
	}
	.my-tag {
		height: 0;
		overflow: hidden;
		padding: 0 36upx;
	}
	.box-video {
		padding-top: 10upx;
	}
	.box-list {
		display: flex;
		justify-content: space-between;
		flex-wrap: wrap;
	}
	.box-list .item-list{
		width: 100%;
		margin-bottom: 20upx;
	}
	.box-list .item-list .item-img {
		border-radius: 6upx;
		display: block;
		/* height: 150px; */
		position: relative;
		overflow: hidden;
		text-align: center;
		background-size: 60%;
	}
	.box-list .item-list .item-title {
		margin: 6upx 0 10upx;
		width: 100%;
		text-overflow: ellipsis;
		white-space: nowrap;
		overflow: hidden;
		display: flex;
		justify-content: space-between;
	}
	.box-list .item-list .item-title .t-info {
		max-width: 50%;
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
	}
	.box-list .item-list .item-title em {
		font-style: normal;
		color: #d349f7;
	}
	.box-list .item-list .item-img span{
		color: #f97937;
		font-weight: 600;
		position: absolute;
		right: 10upx;
		bottom: 10upx;
	}
</style>
