<template>
	<view class="content">
		<!-- #ifdef APP-PLUS -->
		<view class="status_bar"><view class="top_view"></view></view>
		<!-- #endif -->
		
		<view class="t-head">
			<view class="head-cont">
				<view class="head-back" @click="goRouteBack">
					<uni-icons type="arrowleft" size="20" color="#ffffff" />
				</view>
				<view class="head-title">
					{{ menu.category }}
				</view>
				<view class="head-r" @click="goRoute">
					<image class="img" src="../../static/img/history.png" mode="widthFix"></image>
				</view>
				<view class="top-v">
					<view class="search">
						<view class="ico-sear">
							<uni-icons type="search" size="20" color="#d349f7" />
						</view>
						<input class="search-txt" type="text" value="" />
					</view>
					<view class="bars">
						<show-bar class="bar-list" @selectMenu="selectMenu"></show-bar>
					</view>
				</view>
			</view>
		</view>
		
		<view class="vip-txt">
			<view class="vip-ico">
				<image class="img" src="../../static/img/vip.png" mode="widthFix"></image>
			</view>
			<text>推广一人无限观影&nbsp;&nbsp;任性看</text>
		</view>
		
		<view class="box-list w-94">
			<view class="item-list" v-for="(item, idx) in dataList" :key="idx" @click="goDetail(item)">
				<view class="item-img">
					<image class="img" :src="item.img" mode="widthFix" @error="imageError"></image>
					<span>{{ (item.pay_total / $payCont).toFixed(2) }}</span>
				</view>
				<view class="item-title">{{ item.title }}</view>
			</view>
			<view class="item-list no-data"></view>
			<view class="item-list no-data"></view>
		</view>
		
		<uni-load-more :status="loadStatus" :contentText="contentText" @clickLoadMore="clickLoadMore"></uni-load-more>
		<!-- #ifdef H5 -->
		<view class="status_tabar"></view>  
		<!-- #endif -->
	</view>
</template>

<script>
	import {uniIcons,uniLoadMore} from '@dcloudio/uni-ui'
	import showBar from '@/components/show-bar/bar.vue'
	export default {
		components: {uniIcons,showBar,uniLoadMore},
		data() {
			return {
				menu: {},
				dataList: [],
				loadStatus: 'more',
				page: 1,
				contentText: {
					contentdown: '点击加载更多',
					contentrefresh: '正在加载...',
					contentnomore: '我是有底线的'
				}
			}
		},
		onLoad(option) {
			var storeMenu = this.$store.state.menu;
			var menu = storeMenu.filter(item => item.type == option.type)[0] || {};
			this.$set(this,'menu', menu);
			this.getList();
		},
		onPullDownRefresh() {
			this.page = 1;
			this.loadStatus = 'loading';
			this.getList(true);
		},
		onReachBottom() {
			this.getList();
		},
		methods: {
			goRouteBack(url) {
				// #ifdef APP-PLUS
				uni.navigateBack();
				// #endif
				// #ifdef H5
				window.history.back()
				// #endif
			},
			selectMenu(type) {
				uni.redirectTo({
					url: '/pages/list/list?type=' + type
				});
			},
			clickLoadMore() {
				this.getList();
			},
			goDetail(item) {
				this.$store.commit('playDataChange', item);
				uni.navigateTo({
					url: '/pages/play/play?id=' + item.id
				});
			},
			goRoute() {
				uni.navigateTo({
					url: '/pages/my/history'
				});
			},
			getList(refresh) {
				if (this.loadStatus === 'noMore') {
					return;
				};
				var vm = this;
				this.loadStatus = 'loading';
				uni.request({
					url: this.$resource + '/app/tList',
					method: 'POST',
					data: {pageSize: 9, page: vm.page, type: this.menu.type},
					header:{
						'content-type':'application/x-www-form-urlencoded'
					},
					success: (res) => {
						var list = res.data.data || [];
						var newList = vm.dataList.concat(list);
						vm.$set(vm, 'dataList', newList);
						vm.loadStatus = 'more';
						vm.page += 1;
						if (list.length < 9) {
							vm.loadStatus = 'noMore';
						}
						if(refresh) {
							uni.stopPullDownRefresh();
						}
					},
					fail: (res) => {
						uni.showModal({
							content: '加载数据失败',
							showCancel: false
						})
					},
					complete: () => {
						uni.hideLoading();
					}
				});
			}
		}
	}
</script>

<style>
	/* .content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	} */
	.t-head {
		height: 180upx;
	}
	.head-cont{
		flex-wrap: wrap;
		height: 180upx;
	}
	.top-v{
		height: 72upx;
		display: flex;
		width: 100%;
	}
	.top-v .bars{
		width: 60upx;
		height: 60upx;
		line-height: 60upx;
	}
	.search{
		background-color: #1e1e1e;
		height: 60upx;
		line-height: 60upx;
		width: 90%;
		margin: 0 auto;
		border-radius: 30upx;
		overflow: hidden;
		position: relative;
		flex: 1;
	}
	.search .ico-sear{
		position: absolute;
		left: 20upx;
		top: 2upx;
	}
	.search .search-txt{
		width: 100%;
		height: 100%;
		color: #fff;
		padding: 10upx 0;
		padding-left: 68upx;
		line-height: 40upx;
	}
	
	.vip-txt {
		display: flex;
		justify-content: center;
		font-size: 22upx;
		color: #999;
		line-height: 21px;
		padding: 20upx 0;
	}
	.vip-txt .vip-ico{
		width: 20px;
		/* padding-top: 8upx; */
	}
	
	.box-list {
		display: flex;
		justify-content: space-between;
		flex-wrap: wrap;
	}
	.box-list .item-list{
		width: 32%;
		text-align: center;
		/* height: 200px; */
	}
	.box-list .no-data{
		height: 0;
	}
	.box-list .item-list .item-img {
		border-radius: 6upx;
		display: flex;
		height: 150px;
		position: relative;
		overflow: hidden;
		align-items: center;
		background-color: #1E1E1E;
	}
	.box-list .item-list .item-title {
		display: block;
		margin: 6upx 0 10upx;
		width: 100%;
		text-overflow: ellipsis;
		white-space: nowrap;
		overflow: hidden;
	}
	.box-list .item-list .item-img span{
		color: #f97937;
		font-weight: 600;
		position: absolute;
		right: 10upx;
		bottom: 10upx;
	}
</style>
