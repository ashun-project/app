<template>
	<view>
		<!-- #ifdef APP-PLUS -->
		<view class="status_bar"><view class="top_view"></view></view>
		<!-- #endif -->
		
		<view class="uni-page-head">
			<view class="">
				<uni-icons @click="goRouteBack" type="arrowleft" size="20" color="#ffffff" />
			</view>
			<view class="uni-page-head-title">
				<text class="uni-page-head-title-txt">{{videoObj.title}}</text>
			</view>
		</view>
		<view class="video-wrap">
			<view class="" v-show="startType === 2">
				<video v-if="videoObj.video" id="myVideo" :src="videoObj.video"
				 @error="videoErrorCallback" @play="videoLoad" controls :poster="videoObj.cover"></video>
				<view v-else class="video-cont">
					<uni-load-more :status="status"/>
				</view>
			</view>
			<view v-show="startType === 1" class="img-over">
				<image :src="$resource + '/banner/' + videoPic.pic" @click="goOut(videoPic.url)" @error="imgLoad" @load="imgLoad" style="width: 100%;" mode="scaleToFill"></image>
				<view class="close-start">
					<text>广告剩余：{{ timesNum }}s</text>
				</view>
			</view>
		</view>
		
		<view class="desc coll">
			<view class="">
				<text class="point txt">{{ (videoObj.pay_total / $payCont).toFixed(2) }}</text>
				<text class="txt">分·</text>
				<text class="point txt">{{ videoObj.pay_total }}</text>
				<text class="">次播放</text>
			</view>
			<view class="coll-img" @click="setStoreValue('store-collection')">
				<image class="img" src="../../static/img/fav.png" mode="widthFix"></image>
			</view>
		</view>
		
		<view class="guanggao guanggao-2">
			<view class="g-list" v-for="(item, idx) in guangaoList" :key="idx" @click="goOut(item.url)">
				<image class="g-img" :src="$resource + '/banner/' + item.pic" mode="widthFix"></image>
			</view>
		</view>
		
		<view class="guess w-94">
			<uni-icons type="hand-thumbsup" size="16" color="#ff09af" />
			<text class="txt">猜您喜欢</text>
		</view>
		<view class="guess-data w-94">
			<view class="gu-list" v-for="item in recommond" :key="item.id" @click="goDetail(item)">
				<view class="g-img">
					<image class="img" :src="item.img" mode="widthFix"></image>
				</view>
				<view class="gu-list-info">
					<view class="v-titel">
						<text>{{ item.title }}</text>
					</view>
					<view class="desc">
						<text class="point txt">{{(item.pay_total / $payCont).toFixed(2) }}</text>
						<text class="txt">分·</text>
						<text class="point txt">{{ item.pay_total }}</text>
						<text class="">次播放</text>
					</view>
				</view>
			</view>
		</view>
		
	</view>
</template>
<script>
	import {uniIcons,uniLoadMore} from '@dcloudio/uni-ui'
	export default {
		components: {
			uniIcons,
			uniLoadMore
		},
		data() {
			return {
				videoObj: {},
				recommond: [],
				status: 'loading',
				datilId: '',
				playArr: [],
				playKey: '',
				pleyed: false,
				guangaoList: [],
				videoPic: {},
				startType: 0,
				timesNum: 5
			}
		},
		onLoad(option) {
			this.getGuangao();
			var vm = this;
			var date = new Date();
			var key = (date.getMonth() + 1) +'-'+ date.getDate();
			var playArr = uni.getStorageSync(key);
			var value = uni.getStorageSync('login-info') || {};
			var type = value.type;
			this.playKey = key;
			this.playArr = playArr || [];
			if (this.playArr.length >= 10 && !type) {
				uni.showModal({
					content: '今日播放次数已达上线，推广一人后可无效观看',
					showCancel: false
				})
			} else {
				this.getInit(option);
			}
		},
		methods: {
			goRouteBack(url) {
				// #ifdef APP-PLUS
				uni.navigateBack();
				// #endif
				// #ifdef H5
				window.history.back()
				// #endif
			},
			goDetail(item) {
				this.$store.commit('playDataChange', item);
				uni.redirectTo({
					url: '/pages/play/play?id=' + item.id
				});
			},
			videoLoad() {
				if (!this.pleyed) {
					var id = this.videoObj.id;
					var fil = this.playArr.filter(item => item == id);
					if (!fil.length) {
						this.playArr.push(id);
						uni.setStorage({
						    key: this.playKey,
						    data: this.playArr
						})
					}
					this.setStoreValue('store-history');
				}
				this.pleyed = true;
			},
			videoErrorCallback(e) {
				uni.showModal({
					content: e.target.errMsg || '未知错误，请选择其他视频',
					showCancel: false
				})
			},
			getInit(option) {
				var playData = this.$store.state.playData || {};
				var title = playData.title || '播放详情';
				this.datilId = option.id;
				this.$set(this, 'videoObj', playData);
				this.getRecommoned();
			},
			getRecommoned(id) {
				uni.request({
					url: this.$resource + '/app/guessList',
					method: 'POST',
					data: {
						type: this.videoObj.type
					},
					header:{
						'content-type':'application/x-www-form-urlencoded'
					},
					success: (res) => {
						this.recommond = res.data.data;
					}
				});
			},
			setStoreValue(key) {
				var vm = this;
				var collection = uni.getStorageSync(key) || [];
				collection.push({ title: vm.videoObj.title, id: vm.videoObj.id, type: vm.videoObj.category });
				uni.setStorage({
				    key: key,
				    data: collection,
				    success: function () {
						if (key === 'store-collection') {
							uni.showToast({
							    title: '收藏成功',
							    duration: 2000,
								position: 'top',
								icon: 'none'
							});
						}
				    }
				});
			},
			getGuangao() {
				var list = this.$store.state.guanggaoList;
				var videoImg = list.filter(item => item.type == 5)[0];
				this.guangaoList = list.filter(item => item.type == 2);
				if (videoImg) {
					this.startType = 1;
					this.$set(this,'videoPic', videoImg);
				}
			},
			imgLoad() {
				var vm = this;
				var timer2 = setInterval(function() {
					if (vm.timesNum == 0) {
						clearInterval(timer2);
						vm.startType = 2;
					} else {
						vm.timesNum--;
					}
				}, 1000)
			},
			goOut(url) {
				if(!url) {
					return
				};
				// #ifdef APP-PLUS
				plus.runtime.openURL(url);
				// #endif
				// #ifndef APP-PLUS
				window.location.href = url;
				//#endif
			}
		}
	}
</script>

<style>
	.uni-page-head{
		display: flex;
		justify-content: space-between;
		padding: 10upx;
		align-items: center;
	}
	.uni-page-head-title{
		height: auto;
		flex: 1;
		padding-left: 20upx;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}
	.uni-page-head-title .uni-page-head-title-txt{
		text-align: left;
		color: #ccc;
		font-size: 32upx;
		height: 50upx;
		line-height: 50upx;
		
	}
	.video-wrap{
		/* width: 100%; */
		padding: 0 15upx;
		position: relative;
	}
	.video-wrap .img-over{
		width: 100%;
		min-height: 225px;
		position: relative;
	}
	.close-start{
		position: absolute;
		top: 20upx;
		right: 20upx;
		z-index: 89898;
	}
	.video-wrap .video-cont{
		width: 100%;
		background: #000;
		min-height: 225px;
		display: flex;
		align-items: center;
		justify-content: center;
		margin-bottom: 30upx;
	}
	video {
		width: 100%;
	}
	#myVideo{
		width: 100%;
		background: #000000;
	}
	.coll{
		display: flex;
		justify-content: space-between;
	}
	.coll-img{
		width: 36upx;
	}
	.desc {
		display: flex;
		padding: 0 20upx;
	}
	.desc .point {
		color: #ff09af;
	}
	.desc .txt{
		padding-right: 6upx;
	}
	.guess {
		padding: 20upx 0;
		/* background-color: #1e1e1e; */
	}
	.guess .txt{
		padding-left: 10upx;
		font-size: 28upx;
	}
	.gu-list {
		display: flex;
		height: 200upx;
		margin-bottom: 20upx;
		overflow: hidden;
	}
	.gu-list .g-img {
		width: 40%;
		height: 100%;
		border-radius: 20upx;
		overflow: hidden;
	}
	.gu-list .gu-list-info {
		flex: 1;
	}
	.gu-list .v-titel {
		font-size: 30upx;
		padding-left: 20upx;
		line-height: 40upx;
		padding-bottom: 20upx;
		padding-top: 10upx;
		max-height: 110upx;
		overflow: hidden;
	}
</style>
