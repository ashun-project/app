import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const store = new Vuex.Store({
	state: {
		menu: [],
		guanggaoList: [],
		playData: {}
	},
	mutations: {
		login(state, provider) {
			state.hasLogin = true;
		},
		menuChange(state, arr) {
			state.menu = JSON.parse(JSON.stringify(arr));
		},
		guanggaoChange(state, arr) {
			state.guanggaoList = JSON.parse(JSON.stringify(arr));
		},
		playDataChange(state, obj) {
			state.playData = JSON.parse(JSON.stringify(obj));
		}
	},
	actions: {
		
	}
})

export default store
